/*
⚠️ PERINGATAN:
Script ini **TIDAK BOLEH DIPERJUALBELIKAN** dalam bentuk apa pun!

╔══════════════════════════════════════════════╗
║                🛠️ INFORMASI SCRIPT           ║
╠══════════════════════════════════════════════╣
║ 📦 Version   : 5.5.0
║ 👨‍💻 Developer  : Azhari Creative              ║
║ 🌐 Website    : https://autoresbot.com       ║
║ 💻 GitHub  : github.com/autoresbot/resbot-md ║
╚══════════════════════════════════════════════╝

📌 Mulai 11 April 2025,
Script **Autoresbot** resmi menjadi **Open Source** dan dapat digunakan secara gratis:
🔗 https://autoresbot.com
*/

// Import ESM
import chokidar from 'chokidar';
import config from './config.js';
const mode = config.mode;

import { findGroup } from './lib/group.js';
import chalk from 'chalk';
import handler from './lib/handler.js';
import mess from './strings.js';
import { updateParticipant } from './lib/cache.js';

import path from 'path';
import { handleActiveFeatures } from './lib/participant_update.js';
import { tanganiErrorDisk } from './lib/diskGuard.js';

import {
  logWithTime,
  log,
  danger,
  success,
  findClosestCommand,
  logTracking,
} from './lib/utils.js';

import { isOwner, hasOwner, isPremiumUser, updateUser, findUser } from './lib/users.js';

import { reloadPlugins } from './lib/plugins.js';
import { logCustom } from './lib/logger.js';
import { createBoundedMap } from './lib/boundedStore.js';
import { isDestinationAllowed } from './lib/destination.js';
import { isAccGroup } from './lib/accGroups.js';
import { devDetect } from './lib/devlog.js';
import { chatBerhenti, chatSelesai, chatTahap, chatError, jejakAktif } from './lib/trace.js';
import { pecahRantai, jalankanRantai } from './lib/rantaiCommand.js';

// Variabel global
// Rate limiter memakai penyimpanan berbatas (TTL + jumlah maksimum). Versi lama
// memakai object biasa yang tidak pernah dibersihkan, sehingga setiap remoteJid
// baru menambah entri permanen selama bot hidup (memory leak).
const lastMessageTime = createBoundedMap({ max: 5000, ttl: 60 * 60 * 1000 });
const lastSent_participantUpdate = createBoundedMap({ max: 5000, ttl: 60 * 60 * 1000 });
// Throttle log "Destination handle only" agar tidak membanjiri console.
const destinationNoticeAt = createBoundedMap({ max: 5000, ttl: 60 * 60 * 1000 });

/** Penanda log 'sesi belum siap' supaya console tidak dibanjiri. */
const sessionNoticeAt = createBoundedMap({ max: 5000, ttl: 60 * 60 * 1000 });
const pluginsPath = path.join(process.cwd(), 'plugins');
let plugins = [];

// Kesiapan handler & plugin — dimuat MALAS (lazy), sekali saja.
//
// Dulu keduanya dimuat saat modul ini di-import, yaitu saat startup, sebelum
// ada sesi yang terhubung. Ratusan plugin ikut di-import walau bot masih
// menunggu pairing / scan QR (atau sesinya logout dan tidak pernah tersambung),
// dan log "Load All ..." bercampur dengan kode pairing di console.
// Tanpa sesi yang terbuka tidak ada pesan yang bisa masuk, jadi pemuatan cukup
// dilakukan saat koneksi pertama 'open' (lihat lib/connection.js).
//
// processMessage tetap meng-await ensureReady() sebagai pengaman: pesan yang
// masuk pada detik-detik awal menunggu sampai handler pengaman (antilink, ban,
// badword, sewa) dan plugin selesai dimuat. Setelah selesai, await pada promise
// yang sudah resolved praktis tanpa biaya.
let readyPromise = null;
let pluginsLoaded = false;

function ensureReady() {
  if (!readyPromise) {
    const handlersReady = handler
      .initHandlers()
      .catch((error) => console.error('❌ ERROR: Gagal memuat handler:', error));

    const pluginsReady = reloadPlugins()
      .then((loadedPlugins) => {
        plugins = loadedPlugins;
        pluginsLoaded = true;
        logWithTime('System', `Load All Plugins done... (${plugins.length} plugin)`);
      })
      .catch((error) => {
        console.error('❌ ERROR: Gagal memuat plugins:', error);
      });

    readyPromise = Promise.all([handlersReady, pluginsReady]).then(() => {
      success('System', `Handler & plugin dimuat (${plugins.length} plugin)`);
    });
  }
  return readyPromise;
}

// Hot reload hanya di development
if (mode === 'development') {
  const watcher = chokidar.watch(pluginsPath, {
    persistent: true,
    ignoreInitial: true,
    ignored: /(^|[\/\\])\../, // Abaikan file tersembunyi
  });

  watcher.on('change', (filePath) => {
    // Plugin belum pernah dimuat (belum ada sesi terhubung): perubahan file
    // otomatis ikut terbaca saat pemuatan pertama nanti.
    if (filePath.endsWith('.js') && pluginsLoaded) {
      logWithTime('System', `File changed: ${filePath}`);

      reloadPlugins()
        .then((loadedPlugins) => {
          plugins = loadedPlugins;
        })
        .catch((error) => {
          console.error('❌ ERROR: Gagal memuat plugins:', error);
        });
    }
  });

  logWithTime('System', 'Hot reload active in development mode.');
} else {
  logWithTime('System', 'Hot reload disabled in production mode.');
}

// Fungsi utama untuk memproses pesan
async function processMessage(sock, messageInfo) {
  const { remoteJid, isGroup, message, sender, senderLid, pushName, fullText, prefix, command } =
    messageInfo;

  const isPremiumUsers = isPremiumUser(senderLid);
  const isOwnerUsers = isOwner(senderLid);

  // ─── Deteksi DEV MODE (hanya log, TIDAK menindak) ──────────────────────
  // Di mode development, laporkan ke console kalau serialize MENGENALI pesan
  // terusan / tag status, WALAUPUN grup belum di-.acc (jadi fitur "on" seperti
  // antiforward / antitagsw tidak akan benar-benar dijalankan). Dipasang SEBELUM
  // semua gerbang (.acc, destination, sesi) supaya tetap tampil untuk grup yang
  // belum diaktifkan. Kalau log ini tidak muncul padahal pesannya forwarded /
  // tag status, berarti serializeMessage.js perlu diperbaiki.
  if (String(config.mode).toLowerCase() === 'development' && !isAccGroup(remoteJid)) {
    const { isForwarded, isTagSw, isTagSwGc, type } = messageInfo;
    if (isForwarded && isGroup) devDetect('antiforward', { remoteJid, sender, isGroup });
    if (isTagSw || isTagSwGc) {
      devDetect('antitagsw', { remoteJid, sender, isGroup, isTagSwGc: Boolean(isTagSwGc) });
    }
    if (type === 'poll' && isGroup) devDetect('antipolling', { remoteJid, sender, isGroup });
  }

  try {
    // ─── Handle Destination ──────────────────────────────────────────────
    // WAJIB dicek paling awal, sebelum handler.preProcess().
    //
    // Sebelumnya pengecekan ini berada jauh di bawah — setelah preProcess —
    // sehingga hanya melindungi pencarian command. Seluruh handler di folder
    // `handle/` sudah terlanjur berjalan lebih dulu, membuat setelan 'private'
    // tidak benar-benar mematikan bot di grup: list & respon tetap dibalas,
    // antilink tetap menghapus/kick, autoai/autosimi/autorusuh tetap menjawab,
    // game tetap dijawab, dan notifikasi sewa tetap terkirim.
    // ─── Mode setup (instalasi baru) ─────────────────────────────────────
    // Selama DATA_OWNER masih kosong, .id boleh dipakai SIAPA PUN di mana pun
    // supaya pemilik bot bisa mengambil LID-nya sendiri untuk diisikan ke
    // DATA_OWNER. Tanpa ini instalasi baru buntu: bot diam di grup yang belum
    // di-.acc, dan chat pribadi pun bisa tertutup oleh setelan DESTINATION.
    // Begitu owner terisi, pengecualian ini mati dengan sendirinya.
    const modeSetup = command === 'id' && !hasOwner();

    if (!isDestinationAllowed(isGroup) && !isOwnerUsers && !modeSetup) {
      // Log dibatasi agar grup yang ramai tidak membanjiri console: cukup
      // sekali per chat per menit, karena isinya selalu sama.
      const lastNotice = destinationNoticeAt.get(remoteJid);
      if (!lastNotice || Date.now() - lastNotice > 60_000) {
        destinationNoticeAt.set(remoteJid, Date.now());
        logWithTime('SYSTEM', `Destination handle only - ${config.bot_destination} chat`);
      }
      chatBerhenti(
        'Setelan DESTINATION',
        `bot hanya melayani chat '${config.bot_destination}' (config.js)`,
        messageInfo,
      );
      return;
    }

    // ─── Sistem .acc ─────────────────────────────────────────────────────
    // Bot diam total di grup yang belum diaktifkan owner (.acc): tidak ada
    // handler (antilink, list, game, autoai, dll) maupun plugin yang jalan.
    // Owner tetap dilayani supaya bisa mengetik .acc di grup tersebut.
    if (isGroup && !isOwnerUsers && !isAccGroup(remoteJid) && !modeSetup) {
      // Alasannya dicatat lewat jejak chat (hanya muncul di mode development,
      // supaya console mode production tetap rapi).
      chatBerhenti('Sistem .acc', 'grup ini belum diaktifkan owner (ketik .acc di grup)', messageInfo);
      return;
    }

    // Sesi yang sedang putus/reconnect TIDAK bisa mengirim apa pun: zapo
    // melempar "sendMessage requires registered meJid" begitu ada balasan
    // dikirim. Pesan yang terlanjur masuk sebelum putus akan menabrak error itu
    // di tengah plugin — termasuk saat plugin mencoba mengirim pesan errornya
    // sendiri, sehingga di console cuma terlihat "Kesalahan di processMessage".
    if (typeof sock.sessionReady === 'function' && !sock.sessionReady()) {
      const lastNotice = sessionNoticeAt.get(remoteJid);
      if (!lastNotice || Date.now() - lastNotice > 60_000) {
        sessionNoticeAt.set(remoteJid, Date.now());
        logWithTime('SYSTEM', 'Sesi belum siap kirim pesan - pesan masuk dilewati');
      }
      chatBerhenti('Sesi WhatsApp', 'sesi sedang putus/reconnect, bot belum bisa mengirim', messageInfo);
      return;
    }

    // Pastikan handler & plugin selesai dimuat sebelum pesan diproses.
    await ensureReady();

    // Nama handler yang menghentikan dicatat di lib/handler.js lalu dibaca di
    // sini, supaya baris [CHAT BERHENTI] menyebut fitur yang tepat.
    const shouldContinue = await handler.preProcess(sock, messageInfo);
    if (!shouldContinue) {
      chatBerhenti(
        `Handler: ${messageInfo.dihentikanOleh || 'tidak diketahui'}`,
        'fitur ini sengaja menghentikan pemrosesan pesan',
        messageInfo,
      );
      return; // Jika handler.js memutuskan untuk berhenti
    }

    // Rate limiter
    let truncatedContent = fullText.length > 10 ? fullText.slice(0, 10) + '...' : fullText;

    const currentTime = Date.now();
    const lastTime = lastMessageTime.get(remoteJid);
    if (lastTime && currentTime - lastTime < config.rate_limit && prefix && !isOwnerUsers) {
      // Di production tetap sependek versi lama. Rinciannya (jendela rate limit
      // ini dipakai BERSAMA satu grup) hanya ditambahkan di mode development,
      // karena di sanalah log dipakai untuk melacak "kenapa bot tidak respon".
      danger(
        pushName,
        jejakAktif()
          ? `Rate limit : ${truncatedContent} - chat ${remoteJid} baru dipakai ${currentTime - lastTime}ms lalu (batas ${config.rate_limit}ms)`
          : `Rate limit : ${truncatedContent}`,
      );
      chatBerhenti(
        'Rate limit',
        `chat ini baru dipakai ${currentTime - lastTime}ms lalu, batas ${config.rate_limit}ms (jendela dipakai BERSAMA satu grup)`,
        messageInfo,
      );
      return;
    }
    if (prefix) {
      lastMessageTime.set(remoteJid, currentTime);
    }

    if (truncatedContent.trim() && prefix) {
      // Pastikan tidak kosong
      const logMessage =
        config.mode === 'production'
          ? () => log(pushName, truncatedContent)
          : () => logWithTime('CHAT', `${pushName}(${sender.split('@')[0]}) - ${truncatedContent}`);

      logMessage();
    }

    if (!pushName || pushName.trim() === '') {
      logWithTime('DOUBLE CHAT', `${sender.split('@')[0]} - (No Name) - ${truncatedContent}`); // JOKOWI
      //console.log(inspect(messageInfo, { depth: 2, colors: false, compact: false }));
    }

    /**
     * Pengecekan izin & limit untuk SATU plugin.
     *
     * Dulu blok ini tertanam di dalam loop plugin di bawah. Dipisah supaya
     * rantai command (`.removebg + sticker`) bisa memanggilnya ULANG untuk
     * setiap langkah - kalau tidak, merantai dua fitur berbayar cuma memotong
     * satu limit.
     *
     * @returns {Promise<boolean>} false = pesan penolakan sudah dikirim
     */
    async function cekIzin(plugin, infoPlugin) {
      const cmd = infoPlugin.command;

      // Cek apakah perintah ini hanya untuk pengguna premium
      if (plugin.OnlyPremium && !isPremiumUsers && !isOwnerUsers) {
        logTracking(`Handler - Bukan premium (${cmd})`);
        chatBerhenti(`Plugin ${cmd}`, 'khusus user premium', infoPlugin);
        await sock.sendMessage(remoteJid, { text: mess.general.isPremium }, { quoted: message });
        return false;
      }

      // Cek apakah perintah ini hanya untuk owner
      if (plugin.OnlyOwner && !isOwnerUsers) {
        logTracking(`Handler - Bukan Owner (${cmd})`);
        chatBerhenti(`Plugin ${cmd}`, 'khusus owner', infoPlugin);
        await sock.sendMessage(remoteJid, { text: mess.general.isOwner }, { quoted: message });
        return false;
      }

      //  fitur baru disini
      // OnlyAdmin: false, // default false
      // OnlyGroup: false, // default false
      // OnlyPrivate: false // default false

      let isGrubPremium = false;
      const settingGroups = await findGroup(remoteJid);
      if (settingGroups?.fitur?.premium && new Date(settingGroups.fitur.premium) > new Date()) {
        // Premium masih aktif
        isGrubPremium = true;
      }

      // Cek apakah perintah ini menggunakan limit
      if (!isPremiumUsers && !isOwnerUsers && plugin.limitDeduction && !isGrubPremium) {
        try {
          const dataUsers = await findUser(senderLid, 'Debug 1');
          if (!dataUsers) {
            chatBerhenti(`Plugin ${cmd}`, `data user ${senderLid} tidak ditemukan`, infoPlugin);
            return false;
          }

          const [docId, userData] = dataUsers;

          const isLimitExceeded = userData.limit < plugin.limitDeduction || userData.limit < 1;
          if (isLimitExceeded) {
            logTracking('Handler - Limit habis ');
            chatBerhenti(`Plugin ${cmd}`, 'limit user habis', infoPlugin);
            await sock.sendMessage(remoteJid, { text: mess.general.limit }, { quoted: message });
            return false;
          }

          // Kurangi limit pengguna jika masih cukup
          await updateUser(senderLid, {
            limit: userData.limit - plugin.limitDeduction,
          });
        } catch (error) {
          console.error(`Terjadi kesalahan saat mengurangi limit pengguna: ${error.message}`);
        }
      }

      return true;
    }

    // ─── Rantai command ──────────────────────────────────────────────────
    // `.removebg + sticker` = jalankan beberapa command berurutan, hasil
    // langkah sebelumnya jadi media masukan langkah berikutnya. Dicek SEBELUM
    // pencarian plugin biasa, karena `command` di sini masih 'removebg' dan
    // akan salah jalan kalau diproses sebagai command tunggal.
    const rantai = pecahRantai(messageInfo, plugins);

    if (rantai?.galat) {
      chatBerhenti('Rantai command', 'susunan rantai tidak valid', messageInfo);
      return await sock.sendMessage(remoteJid, { text: rantai.galat }, { quoted: message });
    }

    if (rantai?.langkah) {
      const urutan = rantai.langkah.map((l) => l.command).join(' -> ');
      chatTahap(`Rantai command dijalankan (${urutan})`, messageInfo);
      await jalankanRantai(sock, messageInfo, rantai.langkah, { plugins, cekIzin });
      chatSelesai(`Rantai command selesai (${urutan})`, messageInfo);
      return;
    }

    let commandFound = false;

    // Iterasi melalui semua plugin untuk menemukan perintah yang sesuai
    for (const plugin of plugins) {
      // Plugin yang cacat (tanpa Commands / bukan array) sebelumnya membuat
      // `plugin.Commands.includes` melempar TypeError. Karena loop ini berada
      // di dalam satu try/catch besar, SATU plugin rusak akan menghentikan
      // pemrosesan SEMUA pesan — bukan hanya command miliknya sendiri.
      if (!Array.isArray(plugin?.Commands) || !plugin.Commands.includes(command)) continue;

      if (typeof plugin.handle !== 'function') {
        danger('Plugin', `Plugin untuk command "${command}" tidak punya fungsi handle`);
        continue;
      }

      commandFound = true;

      if (!(await cekIzin(plugin, messageInfo))) return;

      chatTahap(`Plugin ${command} dijalankan`, messageInfo);
      const pluginResult = await plugin.handle(sock, messageInfo);
      chatSelesai(`Plugin ${command} selesai`, messageInfo);

      logTracking(`Plugins - ${command} dijalankan oleh ${senderLid}`);

      // Cek apakah plugin meminta untuk menghentikan eksekusi
      if (pluginResult === false) {
        return;
      }
    }

    // sampai sini command tidak di temukan
    if (!commandFound && prefix && command) {
      chatBerhenti('Pencarian command', `command '${prefix}${command}' tidak ada di folder plugins`, messageInfo);
    } else if (!commandFound) {
      // Pesan biasa (bukan command). Sudah lewat semua handler tanpa dihentikan.
      chatSelesai('Pesan biasa - tidak ada command untuk dijalankan', messageInfo);
    }

    if (config.commandSimilarity && !commandFound) {
      const closestCommand = findClosestCommand(command, plugins);
      if (closestCommand && command != '' && fullText.length < 20 && prefix) {
        logTracking(`Handler - Command tidak ditemukan (${command})`);
        logCustom(
          'info',
          `_Command *${command}* tidak ditemukan_ \n\n_Apakah maksud Anda *.${closestCommand}*?_`,
          `ERROR-COMMAND-NOT-FOUND.txt`,
        );
        return await sock.sendMessage(
          remoteJid,
          {
            text: `_Command *${command}* tidak ditemukan_ \n\n_Apakah maksud Anda *.${closestCommand}*?_`,
          },
          { quoted: message },
        );
      }
    }
  } catch (error) {
    logCustom('error', error, `ERROR-processMessage.txt`);
    tanganiErrorDisk(error);
    chatError('processMessage', error, messageInfo);
    danger(command, `Kesalahan di processMessage: ${error}`);
  }
}

async function participantUpdate(sock, messageInfo) {
  const { id, action, participants } = messageInfo;
  const now = Date.now();

  try {
    const settingGroups = await findGroup(id);
    const validActions = ['promote', 'demote', 'add', 'remove'];

    if (validActions.includes(action)) {
      try {
        // updateParticipant adalah async: tanpa await, kegagalannya lolos dari
        // try/catch ini dan menjadi unhandledRejection.
        await updateParticipant(sock, id, participants, action);
      } catch (e) {
        console.log('error updateParticipant :', e?.message || e);
      }
    } else {
      return console.log('action tidak valid :', action);
    }

    // Event ini selalu berasal dari grup. Saat bot dibatasi ke chat pribadi,
    // fitur grup (welcome, goodbye, dll) tidak boleh ikut jalan.
    //
    // Pembaruan cache participant di atas sengaja TETAP dijalankan: owner masih
    // boleh memakai command di grup, jadi data peserta tidak boleh basi.
    if (!isDestinationAllowed(true)) {
      return;
    }

    // Grup yang belum di-.acc: welcome/left/promote/dll tidak dikirim.
    if (!isAccGroup(id)) {
      return;
    }

    // Jika grup ditemukan
    if (settingGroups) {
      // Dihitung per ORANG per aksi, bukan per grup.
      //
      // Dulu kuncinya cuma `id` (grup), sehingga saat beberapa orang
      // masuk/keluar berdekatan hanya yang PERTAMA disapa — sisanya terbuang
      // sebagai "rate limit". Yang perlu ditahan sebenarnya hanya event
      // berulang untuk orang yang sama.
      const target = participants?.[0];
      const kunci = `${id}-${action}-${typeof target === 'string' ? target : target?.id || ''}`;

      const lastSent = lastSent_participantUpdate.get(kunci);
      if (lastSent && now - lastSent < config.rate_limit) {
        return console.log(chalk.redBright(`Rate limit : ${kunci}`));
      }
      lastSent_participantUpdate.set(kunci, now);

      await handleActiveFeatures(sock, messageInfo, settingGroups.fitur);
    }
  } catch (error) {
    logCustom('error', error, `ERROR-participantUpdate.txt`);
    console.error(chalk.redBright(`Error: ${error.message}`));
  }
}

export { processMessage, participantUpdate, ensureReady };
