import { removeUser, getUser, isUserPlaying } from '../../database/temporary_db/tesbutawarna.js';
import { addUser, updateUser, deleteUser, findUser } from '../../lib/users.js';
import mess from '../../strings.js';

async function process(sock, messageInfo) {
  const { remoteJid, content, fullText, message, sender, senderLid } = messageInfo;

  if (isUserPlaying(remoteJid)) {
    const data = getUser(remoteJid);

    // Ketika menyerah
    if (fullText.toLowerCase().includes('nyerah')) {
      if (data && data.timer) {
        clearTimeout(data.timer);
      }

      removeUser(remoteJid);

      if (mess.game_handler.menyerah) {
        const messageWarning = mess.game_handler.menyerah
          .replace('@answer', data.answer)
          .replace('@command', data.command);

        await sock.sendMessage(
          remoteJid,
          {
            text: messageWarning,
          },
          { quoted: message },
        );
      }
      return false;
    }

    if (fullText.toLowerCase() === data.answer) {
      const hadiah = data.hadiah;

      // Mencari pengguna
      const user = await findUser(senderLid, 'tebak gambar game');

      if (user) {
        const [docId, userData] = user;
        const moneyAdd = (userData.money || 0) + hadiah; // Default money ke 0 jika undefined
        await updateUser(senderLid, { money: moneyAdd });
      } else {
      }

      if (data && data.timer) {
        clearTimeout(data.timer);
      }

      removeUser(remoteJid);
      if (mess.game_handler.tebak_gambar) {
        const messageNotif = mess.game_handler.tebak_gambar.replace('@hadiah', hadiah);
        await sock.sendMessage(
          remoteJid,
          {
            text: messageNotif,
          },
          { quoted: message },
        );
      }
      return false;
    }
  }

  return true; // Lanjutkan ke plugin berikutnya
}

export const name = 'Tes Buta Warna';
export const priority = 10;
export { process };
