import fs from 'fs';
import path from 'path';
import { findGroup } from '../../lib/group.js';
import { containsBadword } from '../../lib/badword.js';
import mess from '../../strings.js';
import spamDetection from '../../lib/spamDetection.js';
import badwordDetection from '../../lib/badwordDetection.js';
import config from '../../config.js';
import { devlog, isDevLogEnabled } from '../../lib/devlog.js';
import { updateUser, findUser } from '../../lib/users.js';
import { cariUltah, tandaiUcapan, pindahkanDataLama } from '../../lib/ultahGrup.js';
import autoAi from '../../lib/autoai.js';
import autoSimi from '../../lib/autosimi.js';
import autoRusuh from '../../lib/autorusuh.js';
import { getGroupMetadata, findParticipantLatest } from '../../lib/cache.js';
import {
  logWithTime,
  isUrlInText,
  isUrlInTextSelainWa,
  sendMessageWithMention,
  sendMessageWithMentionNotQuoted,
  logTracking,
  convertToJid,
} from '../../lib/utils.js';
import { findMessageById, editMessageById } from '../../lib/chatManager.js';
import { sendImageAsSticker } from '../../lib/exif.js';
import { logHandlerError } from '../../lib/errorLogger.js'; // FIX: error logger global
import { createBoundedMap, createBoundedSet } from '../../lib/boundedStore.js';
import { isDestinationAllowed } from '../../lib/destination.js';
import { isAccGroup } from '../../lib/accGroups.js';

// Semua penanda di bawah ini memakai penyimpanan berbatas (TTL + jumlah maks).
// Versi lama memakai Set/object biasa yang tidak pernah dibersihkan, sehingga
// setiap user & grup baru menambah entri permanen selama bot hidup.
const notifiedUsers = createBoundedSet({ max: 5000, ttl: 6 * 60 * 60 * 1000 });
const rateLimit_blacklist = createBoundedMap({ max: 5000, ttl: 60 * 60 * 1000 });
const notifiedBlacklistUsers = createBoundedSet({ max: 5000, ttl: 6 * 60 * 60 * 1000 });
// TTL 24 jam: penanda ucapan ulang tahun memang hanya relevan untuk hari ini,
// dan sudah dilapisi userData.lastBirthdayWish yang tersimpan di database.
const notifiedBirthdayUsers = createBoundedSet({ max: 5000, ttl: 24 * 60 * 60 * 1000 });

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Ambang panjang TEKS (bukan objek pesan) yang dianggap virtex. */
const BATAS_VIRTEX = 10000;

const botNumber = config.phone_number_bot; // misalnya '1234'

// CATATAN: fungsi ini TIDAK boleh dinamai `process` — nama itu membayangi objek
// global Node `process`, sehingga `process.env.*` di dalam fungsi membaca properti
// dari fungsi ini (undefined) dan memicu error. Dinamai `handleModeOn`.
async function handleModeOn(sock, messageInfo) {
  const {
    m,
    id,
    sender,
    senderLid,
    isBot,
    pushName,
    message,
    isGroup,
    prefix,
    command,
    fullText,
    rawText,
    type,
    isQuoted,
    isTagSw,
    isTagSwGc,
    isTagMeta,
    isForwarded,
    isTagComunity,
    mentionedJid,
    senderType,
  } = messageInfo;

  let { remoteJid } = messageInfo;

  // [DEBUG ANTIFORWARD] jejak alur khusus pesan terusan: kalau sebuah tahap
  // tidak muncul di console, berarti handler berhenti sebelum tahap itu.
  // MATI secara default — nyalakan dengan env DEBUG_ANTIFORWARD=1 (sama dengan
  // log [ANTIFORWARD][serialize]) hanya saat perlu men-debug.
  const dbgFwd = (tahap, extra = {}) => {
    if (!isForwarded || process.env.DEBUG_ANTIFORWARD !== '1') return;
    console.log('[ANTIFORWARD][handler]', tahap, JSON.stringify({ id, remoteJid, sender, ...extra }));
  };
  dbgFwd('masuk handler', { isGroup, isTagSw, command });

  // Hanya pesan dari status@broadcast yang perlu dialihkan ke grup terakhir
  // pengirimnya. Tag status yang datang di grup sudah punya remoteJid yang
  // benar — dulu ikut dialihkan sehingga peringatan/hapus bisa nyasar ke grup lain.
  if (isTagSw && remoteJid === 'status@broadcast') {
    const result = findParticipantLatest(senderLid);
    if (result) remoteJid = result.groupId;
  }

  // FIX: remoteJid undefined protection
  if (!remoteJid || typeof remoteJid !== 'string') {
    logHandlerError('[REMOTE_JID_MISSING]', {
      plugin: 'MODE ON/handler.js',
      command,
      sender,
    });
    return true;
  }

  if (isTagSw || isGroup) {
    // lanjut
  } else {
    return true; // Abaikan jika bukan grup
  }

  // Mulai titik ini seluruh tindakan handler menyasar GRUP (hapus pesan, kick,
  // kirim peringatan). Jalur tag status (isTagSw) lolos dari filter destination
  // di autoresbot.js karena remoteJid-nya 'status@broadcast' (bukan grup), lalu
  // dialihkan ke grup di atas — jadi filternya diulang di sini.
  if (!isDestinationAllowed(true)) {
    dbgFwd('STOP: isDestinationAllowed=false');
    return true;
  }

  // Sama seperti di atas: jalur tag status lolos dari cek .acc di
  // autoresbot.js (remoteJid-nya 'status@broadcast'), jadi grup tujuannya
  // dicek ulang di sini. Grup yang belum di-.acc tidak boleh kena tindakan.
  if (!isAccGroup(remoteJid)) {
    dbgFwd('STOP: grup belum di-.acc');
    return true;
  }

  const now = Date.now();

  try {
    // Ambil data grup dari database
    const dataGroupSettings = await findGroup(remoteJid);
    if (!dataGroupSettings) {
      dbgFwd('STOP: data grup tidak ditemukan');
      logWithTime('System', `Data grup tidak ditemukan atau fitur belum diaktifkan.`);
      return true;
    }

    const { fitur } = dataGroupSettings;

    // Mendapatkan metadata grup
    const groupMetadata = await getGroupMetadata(sock, remoteJid);

    // FIX: participants validation - groupMetadata bisa null (broadcast/gagal fetch)
    const participants = groupMetadata?.participants || [];
    if (!Array.isArray(participants) || participants.length === 0) {
      dbgFwd('STOP: participants kosong');
      logHandlerError('[PARTICIPANTS_UNDEFINED]', {
        plugin: 'MODE ON/handler.js',
        command,
        sender,
        remoteJid,
      });
      return true; // Lanjutkan ke plugin berikutnya tanpa crash
    }

    const isAdmin = participants.some(
      (p) => (p.phoneNumber === sender || p.id === senderLid) && p.admin,
    );

    dbgFwd('data grup OK', {
      isAdmin,
      antiforward: fitur?.antiforward,
      antiforward2: fitur?.antiforward2,
    });

    if (isDevLogEnabled()) {
      devlog('admin', {
        remoteJid,
        command,
        sender,
        senderLid,
        isAdmin,
        // Kandidat yang cocok sebagian: kalau ini terisi tapi isAdmin false,
        // berarti pencocokan jid-nya benar tapi field admin-nya yang salah.
        cocokSender: participants
          .filter((p) => p.phoneNumber === sender || p.id === senderLid)
          .map((p) => ({ id: p.id, phoneNumber: p.phoneNumber, admin: p.admin })),
        totalPeserta: participants.length,
        contohPeserta: participants
          .slice(0, 3)
          .map((p) => ({ id: p.id, phoneNumber: p.phoneNumber, admin: p.admin })),
      });
    }

    // Fungsi untuk menghapus pesan
    const deleteMessage = async () => {
      logTracking(`Menghapus pesan di grub (${command})`);
      // `fromMe: false` WAJIB eksplisit: zapo membangun key revoke dari
      // `key.fromMe` apa adanya, dan tanpa field ini WhatsApp menolak
      // penghapusan pesan orang lain tanpa memberi error yang terlihat.
      //
      // Key revoke dibangun dari KEY ASLI pesan (message.key) bila ada, supaya
      // membawa `participantAlt` (nomor @s.whatsapp.net) dan mode addressing
      // yang sama dengan pesan aslinya. Versi lama hanya mengirim
      // `{ remoteJid, id, participant: <lid> }` — cukup untuk pesan media biasa,
      // tapi tidak selalu cocok untuk pesan khusus seperti tag status
      // (groupStatusMentionMessage), sehingga revoke-nya diterima tapi TIDAK
      // menghapus apa pun.
      const baseKey = (message && typeof message === 'object' && message.key) || {};
      const target = {
        ...baseKey,
        remoteJid, // pakai remoteJid handler (sudah dialihkan bila tag status)
        id: id || baseKey.id,
        participant: baseKey.participant || senderLid,
        participantAlt: baseKey.participantAlt || sender,
        fromMe: false,
      };
      try {
        const result = await sock.sendMessage(remoteJid, { delete: target });
        devlog('handler', { aksi: 'deleteMessage', ok: true, command, target, hasil: result?.key?.id });
      } catch (error) {
        devlog('handler', {
          aksi: 'deleteMessage',
          ok: false,
          command,
          target,
          error: error?.message ?? String(error),
        });
        throw error;
      }
    };

    // Fungsi untuk memproses kick anggota
    const kickParticipant = async () => {
      logTracking(`Kick peserta dari grub (${command})`);
      await sock.groupParticipantsUpdate(remoteJid, [sender], 'remove');
    };

    // Kirim pesan
    const sendText = async (text, isquoted = false) => {
      logTracking(`Handler - mengirim pesan teks (${command})`);
      if (isquoted) {
        await sendMessageWithMentionNotQuoted(sock, remoteJid, text, senderType);
      } else {
        await sock.sendMessage(remoteJid, { text }, { quoted: message });
      }
    };

    async function handleAction(action, sender) {
      if (action === 'block') {
        await updateUser(sender, { status: 'block' });
      } else if (action === 'kick') {
        await kickParticipant();
      } else if (action === 'both') {
        await updateUser(sender, { status: 'block' });
        await kickParticipant();
      } else {
        console.warn('Tindakan badword tidak valid:', action);
      }
    }

    // Mencari pengguna
    const user = await findUser(senderLid, 'Debug 6');

    const isWhatsappLink = fullText.toLowerCase().trim().includes('chat.whatsapp.com');

    const isWhatsappSaluran = fullText.toLowerCase().trim().includes('whatsapp.com/channel/');

    if (isDevLogEnabled()) {
      // Kalau antilink "tidak jalan", jawabannya ada di sini: apakah teksnya
      // terbaca, apakah fitur menyala, dan apakah pengirim dianggap admin
      // (admin sengaja dikecualikan dari semua antilink).
      devlog('handler', {
        aksi: 'cekAntilink',
        remoteJid,
        command,
        isAdmin,
        fullTextPreview: String(fullText).slice(0, 120),
        isUrl: isUrlInText(fullText),
        // antilink & antilinkv2 memakai nilai INI, bukan `isUrl`: link grup
        // dan saluran WhatsApp sengaja dilewatkan ke antilinkwa/antilinkch.
        isUrlSelainWa: isUrlInTextSelainWa(fullText),
        isWhatsappLink,
        isWhatsappSaluran,
        fitur: {
          antilink: fitur.antilink,
          antilinkv2: fitur.antilinkv2,
          antilinkwa: fitur.antilinkwa,
          antilinkwav2: fitur.antilinkwav2,
          antilinkch: fitur.antilinkch,
          antilinkchv2: fitur.antilinkchv2,
        },
      });
    }

    if (!isAdmin && fitur.antilinkwav2 && isWhatsappLink) {
      logWithTime('SYSTEM', `Deteksi fitur Anti-link wav2 : ${fullText}`);
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    // Anti-link ch : Hapus pesan jika URL whatsapp terdeteksi
    if (!isAdmin && fitur.antilinkchv2 && isWhatsappSaluran) {
      logWithTime('SYSTEM', `Deteksi fitur Anti-linkch V2`);
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    if (!isAdmin && fitur.antilinkch && isWhatsappSaluran) {
      logWithTime('SYSTEM', `Deteksi fitur antilinkch : ${fullText}`);
      await deleteMessage();
    }

    // Anti-link wa : Hapus pesan jika URL whatsapp terdeteksi
    if (!isAdmin && fitur.antilinkwa && isWhatsappLink) {
      logWithTime('SYSTEM', `Deteksi fitur antilinkwa : ${fullText}`);
      await deleteMessage();
    }

    // Anti-link V2: Hapus pesan + kick pengguna
    //
    // Link grup & saluran WhatsApp TIDAK dihitung di sini — keduanya punya
    // penangan sendiri (antilinkwav2 / antilinkchv2). Sebelumnya antilink umum
    // ikut menangkapnya, sehingga menyalakan antilink saja sudah membuat
    // setelan antilinkwa/antilinkch tidak ada gunanya.
    if (!isAdmin && fitur.antilinkv2 && isUrlInTextSelainWa(fullText)) {
      logWithTime('SYSTEM', `Deteksi fitur Anti-link V2`);
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    // Anti-link: Hapus pesan jika URL terdeteksi
    // (kecuali link grup/saluran WhatsApp — lihat catatan di Anti-link V2)
    if (!isAdmin && fitur.antilink && isUrlInTextSelainWa(fullText)) {
      logWithTime('SYSTEM', `Deteksi fitur antilink`);
      await deleteMessage();
      return false;
    }

    // ANTI HIDETAG V2
    if (!isAdmin && fitur.antihidetag2 && mentionedJid.length > 0) {
      logWithTime('SYSTEM', `Deteksi fitur antihidetagv2`);

      const hidden = !mentionedJid.some((jid) => {
        // Ambil hanya angka sebelum @
        const number = jid.split('@')[0];
        return fullText.includes(number);
      });

      if (hidden) {
        await deleteMessage();
        await kickParticipant();
        //console.log(`Hidden tag terdeteksi oleh ${sender}`);
        return false;
      }
    }

    // ANTI HIDETAG V1
    if (!isAdmin && fitur.antihidetag && mentionedJid.length > 0) {
      logWithTime('SYSTEM', `Deteksi fitur antihidetag`);

      const hidden = !mentionedJid.some((jid) => {
        // Ambil hanya angka sebelum @
        const number = jid.split('@')[0];
        return fullText.includes(number);
      });

      if (hidden) {
        await deleteMessage();
        //console.log(`Hidden tag terdeteksi oleh ${sender}`);
        return false;
      }
    }

    // Detectblacklist2
    if (fitur.detectblacklist2 && user) {
      logWithTime('SYSTEM', `Deteksi fitur Detect Blacklist`);

      if (user) {
        const [docId, userData] = user;
        const status = userData.status;
        if (status === 'blacklist') {
          // user di blacklist
          await kickParticipant();
        }
      }
    }

    // Detect blacklist
    if (fitur.detectblacklist && user) {
      logWithTime('SYSTEM', `Deteksi fitur Detect Blacklist`);

      if (user) {
        const [docId, userData] = user;

        const status = userData.status;
        const userId = senderLid.split('@')[0]; // Mengambil ID pengguna

        if (status === 'blacklist') {
          if (!notifiedBlacklistUsers.has(userId)) {
            const numberJid = await convertToJid(sock, userId);

            const warningMessage = `⚠️ _Peringatan Blacklist_ \n\n@${numberJid.split('@')[0]} Telah di blacklist`;
            await sendText(warningMessage, true);
            logWithTime(pushName, `User sedang di blacklist`);
            notifiedBlacklistUsers.add(userId); // Tandai sebagai sudah diberi notifikasi
          } else {
            logWithTime(pushName, `User blacklist sudah diberi notifikasi sebelumnya`);
          }
          return false;
        }
      }
    }

    if (fitur.detectblacklist && fitur.detectblacklist2) {
      if (user) {
        const [docId, userData] = user;
        const status = userData.status;
        if (status === 'blacklist') {
          return false;
        }
      }
    }

    // Deteksi badword:
    if (!isAdmin && fitur.badwordv3 && command !== 'delbadword') {
      const hasBadwordGroup = await containsBadword(remoteJid, fullText);
      const hasBadwordGlobal = await containsBadword('global-badword', fullText);

      if (hasBadwordGroup.status || hasBadwordGlobal.status) {
        // Cek salah satu terdeteksi badword
        logWithTime('SYSTEM', `Deteksi fitur badwordv3`);
        await deleteMessage();

        const detectWords = hasBadwordGroup.words || hasBadwordGlobal.words;

        const result = badwordDetection(senderLid);
        if (result.status === 'warning') {
          if (mess.handler.badword_warning) {
            let warningMessage = mess.handler.badword_warning
              .replace('@sender', `@${sender.split('@')[0]}`)
              .replace('@warning', result.totalWarnings)
              .replace('@detectword', detectWords)
              .replace('@totalwarning', config.BADWORD.warning);

            await sendText(warningMessage, true);
          }
          return false;
        }

        if (result.status === 'blocked') {
          if (mess.handler.badword_block) {
            let warningMessage = mess.handler.badword_block
              .replace('@sender', `@${sender.split('@')[0]}`)
              .replace('@warning', result.totalWarnings)
              .replace('@detectword', detectWords)
              .replace('@totalwarning', config.BADWORD.warning);

            await sendText(warningMessage, true);
            await kickParticipant();
          }
        }
      }
    }

    // Deteksi badword v1: Hapus pesan jika ada kata kasar
    if (!isAdmin && fitur.badword && command !== 'delbadword') {
      const hasBadwordGroup = await containsBadword(remoteJid, fullText);
      const hasBadwordGlobal = await containsBadword('global-badword', fullText);

      if (hasBadwordGroup.status || hasBadwordGlobal.status) {
        // Cek salah satu terdeteksi badword

        const detectWords = hasBadwordGroup.words || hasBadwordGlobal.words;

        logWithTime('SYSTEM', `Deteksi fitur badword`);
        await deleteMessage();

        // const result = badwordDetection(senderLid);
        // if (result.status === 'warning') {
        //   if (mess.handler.badword_warning) {
        //     let warningMessage = mess.handler.badword_warning
        //       .replace('@sender', `@${sender.split('@')[0]}`)
        //       .replace('@warning', result.totalWarnings)
        //       .replace('@detectword', detectWords)
        //       .replace('@totalwarning', config.BADWORD.warning);

        //     await sendText(warningMessage, true);
        //   }
        //   return false;
        // }

        // if (result.status === 'blocked') {
        //   if (mess.handler.badword_block) {
        //     let warningMessage = mess.handler.badword_block
        //       .replace('@sender', `@${sender.split('@')[0]}`)
        //       .replace('@warning', result.totalWarnings)
        //       .replace('@detectword', detectWords)
        //       .replace('@totalwarning', config.BADWORD.warning);

        //     await sendText(warningMessage, true);
        //   }

        //   // Ambil tindakan berdasarkan konfigurasi
        //   const badwordAction = config.BADWORD.action.toLowerCase().trim();

        //   try {
        //     if (user) {
        //       const [docId, userData] = user;
        //       await handleAction(badwordAction, senderLid);
        //     }
        //   } catch (error) {
        //     console.error(
        //       '❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_',
        //     );
        //     await sendText(
        //       '❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_',
        //     );
        //   }
        // }
        return false;
      }
    }

    // Deteksi badword v2: Hapus pesan jika ada kata kasar
    if (!isAdmin && fitur.badwordv2 && command !== 'delbadword') {
      const hasBadwordGroup = await containsBadword(remoteJid, fullText);
      const hasBadwordGlobal = await containsBadword('global-badword', fullText);

      if (hasBadwordGroup.status || hasBadwordGlobal.status) {
        // Cek salah satu terdeteksi badword
        logWithTime('SYSTEM', `Deteksi fitur badwordv2`);
        await deleteMessage();

        const detectWords = hasBadwordGroup.words || hasBadwordGlobal.words;

        const result = badwordDetection(senderLid);

        if (mess.handler.badword_block) {
          let warningMessage = mess.handler.badword_block
            .replace('@sender', `@${sender.split('@')[0]}`)
            .replace('@warning', result.totalWarnings)
            .replace('@detectword', detectWords)
            .replace('@totalwarning', config.BADWORD.warning);

          await sendText(warningMessage, true);
        }

        // Ambil tindakan berdasarkan konfigurasi
        const badwordAction = config.BADWORD.action.toLowerCase().trim();

        try {
          if (user) {
            const [docId, userData] = user;
            await handleAction(badwordAction, senderLid);
          }
        } catch (error) {
          console.error(
            '❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_',
          );
          await sendText(
            '❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_',
          );
        }

        return false;
      }
    }

    // Deteksi antigame
    if (fitur.antigame && command) {
      const Games = [
        'bj',
        'blackjack',
        'caklontong',
        'kodam',
        'cekkodam',
        'snakes',
        'dare',
        'family100',
        'kuismath',
        'math',
        'suit',
        'tebakangka',
        'tebakbendera',
        'tebakbom',
        'tebakgambar',
        'tebakhewan',
        'tebakkalimat',
        'tebakkata',
        'tebaklagu',
        'tebak',
        'tebaklirik',
        'tictactoe',
        'truth',
        'ttc',
        'ttt',
      ];
      if (Games.some((game) => command.includes(game))) {
        const notifKey = `antigame-${remoteJid}-${sender}`;
        if (!notifiedUsers.has(notifKey)) {
          notifiedUsers.add(notifKey);
          await sendText(mess.game.isStop);
        }
        return false;
      }
    }

    // Anti-anti
    const antiFeatures = {
      image: fitur.antifoto,
      viewonce: fitur.antifoto,
      video: fitur.antivideo,
      audio: fitur.antiaudio,
      document: fitur.antidocument,
      contact: fitur.anticontact,
      sticker: fitur.antisticker,
      poll: fitur.antipolling,
    };

    if (!isAdmin && antiFeatures[type]) {
      logWithTime('SYSTEM', `Deteksi fitur - ${type}`);
      await deleteMessage();
      return false;
    }

    // Deteksi anti-edit
    if (fitur.antiedit && m.isEdited.status) {
      const fullText = m.isEdited.text;
      const idChatEdited = m.isEdited.id;
      if (idChatEdited) {
        const oldMessage = findMessageById(sender, idChatEdited);
        if (oldMessage) {
          // Kirim pesan deteksi anti-edit
          if (mess.handler.antiedit) {
            let warningMessage = mess.handler.antiedit.replace(
              '@oldMessage',
              `${oldMessage.text || ''}`,
            );

            await sendText(warningMessage, true);
          }

          if (fullText) {
            // Perharui chat edit
            editMessageById(sender, idChatEdited, fullText);
            return false;
          }
        }
      }
    }

    // Deteksi anti-delete
    if (fitur.antidelete && m.isDeleted) {
      const idChatDeleted = m.message.message?.protocolMessage?.key?.id;
      if (idChatDeleted) {
        const oldMessage = findMessageById(sender, idChatDeleted);
        if (oldMessage) {
          if (oldMessage.type && oldMessage.type == 'sticker') {
            try {
              // Ambil direktori kerja saat ini
              const outputPath = path.resolve('./', oldMessage.text); // Resolusi path absolut
              const stickerBuffer = fs.readFileSync(outputPath); // Membaca file dari path

              // Kirim file sebagai stiker
              const options = {
                packname: config.sticker_packname,
                author: config.sticker_author,
              };
              await sendImageAsSticker(sock, remoteJid, stickerBuffer, options, message);

              if (mess.handler.antidelete) {
                let warningMessage = mess.handler.antidelete
                  .replace('@sender', `@${sender.split('@')[0]}`)
                  .replace('@text', 'sticker');

                await sendText(warningMessage, true);
              }
            } catch (error) {
              console.error('Error:', error);
            }
            return;
          }

          // Kirim pesan deteksi anti-delete
          if (mess.handler.antidelete) {
            let warningMessage = mess.handler.antidelete
              .replace('@sender', `@${sender.split('@')[0]}`)
              .replace('@text', `${oldMessage.text || ''}`);
            await sendText(warningMessage, true);
          }
        }
      }
    }

    // Deteksi anti-spam
    if (!isAdmin && typeof fitur.antispamchat === 'boolean' && fitur.antispamchat) {
      const result = spamDetection(senderLid);
      if (result.status === 'warning') {
        if (mess.handler.antispamchat) {
          let warningMessage = mess.handler.antispamchat
            .replace('@sender', `@${sender.split('@')[0]}`)
            .replace('@warning', result.totalWarnings)
            .replace('@totalwarning', config.SPAM.warning);
          try {
            await sendText(warningMessage, true);
          } catch (err) {
            console.error('Gagal kirim pesan warning:', err);
          }
        }
        return false;
      }

      if (result.status === 'blocked') {
        if (mess.handler.antispamchat2) {
          let warningMessage = mess.handler.antispamchat2.replace(
            '@sender',
            `@${senderLid.split('@')[0]}`,
          );
          await sendText(warningMessage, true);
        }

        // Ambil tindakan berdasarkan konfigurasi
        const spamAction = config.SPAM.action.toLowerCase().trim();

        try {
          if (user) {
            const [docId, userData] = user;
            await handleAction(spamAction, senderLid);
          }
        } catch (error) {
          console.error('Terjadi kesalahan saat memproses tindakan spam:', error);
          await sendText('❗ _Terjadi kesalahan, tindakan spam gagal._');
        }

        return false;
      }
    }

    // Deteksi anti-virtex (membatasi teks panjang)
    //
    // Yang diukur HARUS teks yang benar-benar dikirim anggota. Dulu dipakai
    // panjang `toText(message)` alias JSON seluruh objek pesan — di dalamnya
    // ikut terhitung thumbnail base64, kunci media, dan ISI PESAN YANG DIBALAS.
    // Akibatnya membalas pesan panjang (mis. hasil .menu), mengirim stiker,
    // atau meneruskan pesan bergambar bisa tembus 10.000 karakter padahal yang
    // diketik cuma "iya" — anggota yang tidak kirim virtex ikut kena.
    if (!isAdmin && fitur?.antivirtex === true) {
      const teksPesan = typeof rawText === 'string' ? rawText : String(fullText || '');
      const isTextTooLong = teksPesan.length > BATAS_VIRTEX;

      if (isTextTooLong) {
        if (mess.handler.antivirtex) {
          let warningMessage = mess.handler.antivirtex.replace(
            '@sender',
            `@${sender.split('@')[0]}`,
          );
          await sendText(warningMessage, true);
        }
        await deleteMessage();
        return false; // Hentikan eksekusi jika terdeteksi virtex
      }
    }

    // Deteksi auto-ai aktif
    if (fitur?.autoai && command !== 'on' && command !== 'off' && !prefix) {
      const containsAI = fullText.toLowerCase().trim().includes('ai');
      const isQuotedMessageFromBot = (() => {
        if (!isQuoted?.sender) return false;

        // Ambil angka sebelum @
        const senderNumber = isQuoted.sender.split('@')[0];

        return senderNumber === botNumber;
      })();

      // Ambil isi pesan dari kutipan jika pesan berasal dari bot
      const content_old = isQuotedMessageFromBot
        ? isQuoted.text || isQuoted.content || ''
        : undefined;

      // Cek apakah tipe pesan adalah 'text' atau 'image'
      if (type === 'text' || type === 'image' || containsAI) {
        await autoAi(sock, messageInfo, content_old);
        return false;
      }
    }

    // Deteksi auto-simi aktif
    if (fitur?.autosimi && command !== 'on' && command !== 'off') {
      const containsSimi = fullText.toLowerCase().trim().includes('simi');

      const isQuotedMessageFromBot = (() => {
        if (!isQuoted?.sender) return false;

        // Ambil angka sebelum @
        const senderNumber = isQuoted.sender.split('@')[0];

        return senderNumber === botNumber;
      })();

      const content_old = isQuotedMessageFromBot
        ? isQuoted.text || isQuoted.content || ''
        : undefined;

      if (type === 'text' || containsSimi) {
        await autoSimi(sock, messageInfo, content_old);
        return false;
      }
    }

    // Deteksi auto-rusuh aktif
    if (fitur?.autorusuh && command !== 'on' && command !== 'off') {
      const isQuotedMessageFromBot = (() => {
        if (!isQuoted?.sender) return false;

        // Ambil angka sebelum @
        const senderNumber = isQuoted.sender.split('@')[0];

        return senderNumber === botNumber;
      })();
      await autoRusuh(sock, messageInfo, isQuotedMessageFromBot);
      return false;
    }

    if (!isAdmin && fitur?.antibot && isBot && isGroup) {
      if (mess.handler.antibot) {
        let warningMessage = mess.handler.antibot.replace('@sender', `@${sender.split('@')[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    // Deteksi onlyadmin
    if (fitur?.onlyadmin) {
      if (command === 'debug') {
        console.log(`Status Only Admin: ${fitur.onlyadmin ? 'Aktif' : 'Nonaktif'}`);
        return false; // Stop setelah menampilkan status debug
      }
      if (!isAdmin) return false; // Hentikan jika bukan admin
    }

    // Deteksi antitag sw

    if (!isAdmin && fitur?.antitagsw && isTagSw) {
      if (mess.handler.antitagsw) {
        let warningMessage = mess.handler.antitagsw.replace('@sender', `@${sender.split('@')[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      return false;
    }

    // Deteksi antitag sw2
    if (!isAdmin && fitur?.antitagsw2 && isTagSw) {
      if (mess.handler.antitagsw) {
        let warningMessage = mess.handler.antitagsw.replace('@sender', `@${sender.split('@')[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    // Deteksi antitagsw gc
    if (!isAdmin && fitur?.antitagswgc && isTagSwGc) {
      if (mess.handler.antitagsw) {
        let warningMessage = mess.handler.antitagsw.replace('@sender', `@${sender.split('@')[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      return false;
    }
    if (!isAdmin && fitur?.antitagswgc2 && isTagSwGc) {
      if (mess.handler.antitagsw) {
        let warningMessage = mess.handler.antitagsw.replace('@sender', `@${sender.split('@')[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    if (fitur?.antitagmeta && isGroup && isTagMeta) {
      let warningMessage = '⚠️ @sender _Terdeteksi Tag Meta Ai di grub ini_';
      if (warningMessage) {
        warningMessage = warningMessage.replace('@sender', `@${sender.split('@')[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      return false;
    }

    if (fitur?.antitagmeta2 && isGroup && isTagMeta) {
      let warningMessage = '⚠️ @sender _Terdeteksi Tag Meta Ai di grub ini_';
      if (warningMessage) {
        warningMessage = warningMessage.replace('@sender', `@${sender.split('@')[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    if (fitur?.notifultah && isGroup) {
      // Ulang tahun disimpan PER GRUP: ucapan hanya dikirim di grup tempat
      // orangnya mendaftar, dan tanda "sudah diucapkan" juga per grup.
      pindahkanDataLama(remoteJid, participants);
      const ultah = cariUltah(remoteJid, [senderLid, sender]);

      if (ultah?.birthday) {
        const today = new Date();
        const day = String(today.getDate()).padStart(2, '0');
        const month = String(today.getMonth() + 1).padStart(2, '0');
        const year = today.getFullYear();

        const todayStr = `${day}-${month}`;
        const birthdayWishKey = `${todayStr}-${year}`;
        const birthdayNotifKey = `${remoteJid}-${ultah.user_num}-${birthdayWishKey}`;

        // cek apakah hari ini ulang tahun
        if (todayStr === ultah.birthday) {
          const hasSentBirthdayWish =
            String(ultah.last_wish) === String(year) ||
            ultah.last_wish === birthdayWishKey ||
            notifiedBirthdayUsers.has(birthdayNotifKey);

          // cek apakah sudah pernah dikirim hari ini
          if (!hasSentBirthdayWish) {
            let warningMessage = mess.handler.notifultah || '@sender Selamat Ulang Tahun 🎉🎂';
            warningMessage = warningMessage.replace('@sender', `@${sender.split('@')[0]}`);

            // tambahkan info ulang tahun ke berapa jika ada tahun lahir
            if (ultah.birth_year) {
              const age = year - ultah.birth_year;
              warningMessage += `\n🎂 Ulang tahun yang ke-*${age}*`;
            }

            // tandai SEBELUM kirim, supaya pesan yang masuk bersamaan tidak
            // sama-sama mengirim ucapan
            notifiedBirthdayUsers.add(birthdayNotifKey);
            await sendText(warningMessage, true);
            tandaiUcapan(remoteJid, ultah.user_num, birthdayWishKey);
            return false;
          }
        }
      }
    }

    // Kalau 'data grup OK' muncul tapi baris ini tidak, berarti ada fitur lain
    // di atas (antilink, antitagsw, dst.) yang sudah return lebih dulu.
    dbgFwd('sampai di cek antiforward', {
      isAdmin,
      isGroup,
      antiforward: fitur?.antiforward,
      antiforward2: fitur?.antiforward2,
      akanDitindak: !isAdmin && isGroup && Boolean(fitur?.antiforward || fitur?.antiforward2),
    });

    if (!isAdmin && fitur?.antiforward && isGroup && isForwarded) {
      let warningMessage = '⚠️ @sender _Terdeteksi Mengirim Pesan Terusan_';
      if (warningMessage) {
        warningMessage = warningMessage.replace('@sender', `@${sender.split('@')[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      return false;
    }

    if (!isAdmin && fitur?.antiforward2 && isGroup && isForwarded) {
      let warningMessage = '⚠️ @sender _Terdeteksi Mengirim Pesan Terusan_';
      if (warningMessage) {
        warningMessage = warningMessage.replace('@sender', `@${sender.split('@')[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    const lastBlacklistCheck = rateLimit_blacklist.get(sender);
    if (lastBlacklistCheck && now - lastBlacklistCheck < 5000) {
      return true;
    } else {
      rateLimit_blacklist.set(sender, now);
    }
  } catch (error) {
    dbgFwd('ERROR', { error: error.message });
    console.error('Terjadi kesalahan pada proses Handler.js:', error.message);
  }
  return true; // Lanjutkan ke plugin berikutnya
}

export default {
  name: 'Mode On Handler :',
  priority: 2,
  process: handleModeOn,
};
