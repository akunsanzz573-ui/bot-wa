import { setGroupSchedule, setJadwalTeks, getJadwalTeks } from '../../lib/participants.js';
import { getGroupMetadata, pesertaAdalahAdmin } from '../../lib/cache.js';
import { isOwner } from '../../lib/users.js';
import mess from '../../strings.js';
import { convertTime, getTimeRemaining } from '../../lib/utils.js';
import { cekSyaratJadwal, botAdalahAdmin } from '../../lib/groupOpenClose.js';

const TIME_REGEX = /^([01]?\d|2[0-3]):[0-5]\d$/; // HH:mm

/**
 * Analisis syarat jadwal SEBELUM jam-nya tiba, supaya admin langsung tahu
 * kalau grup nanti tidak akan ditutup (bot bukan admin, grup belum .acc, dll).
 */
function analisisSyarat(sock, remoteJid, groupMetadata, jam) {
  const masalah = cekSyaratJadwal(sock, remoteJid, groupMetadata);
  if (masalah.length) {
    return (
      `⚠️ *Jadwal tersimpan, TAPI tidak akan berjalan karena:*\n` +
      masalah.map((m, i) => `${i + 1}. ${m.pesan}`).join('\n') +
      `\n\n_Perbaiki hal di atas sebelum jam ${jam} WIB._`
    );
  }
  if (botAdalahAdmin(sock, groupMetadata) === null) {
    return `ℹ️ _Status admin bot tidak bisa dicek, pastikan bot sudah admin._`;
  }
  return `✅ _Cek syarat: bot admin, grup sudah di-.acc, jadwal aktif — siap berjalan._`;
}

async function handle(sock, messageInfo) {
  const { remoteJid, isGroup, message, content, sender, senderLid, command, prefix } = messageInfo;
  if (!isGroup) return; // Hanya untuk grup

  const groupMetadata = await getGroupMetadata(sock, remoteJid);
  if (!groupMetadata?.participants) {
    await sock.sendMessage(
      remoteJid,
      { text: '⚠️ _Gagal mengambil data grup, coba lagi beberapa saat._' },
      { quoted: message },
    );
    return;
  }

  // Pola lama (p.id === sender) selalu meleset di grup ber-alamat LID.
  const isAdmin =
    pesertaAdalahAdmin(groupMetadata.participants, sender, senderLid) || isOwner(senderLid);

  if (!isAdmin) {
    await sock.sendMessage(remoteJid, { text: mess.general.isAdmin }, { quoted: message });
    return;
  }

  const isi = (content || '').trim();

  if (!isi) {
    await sock.sendMessage(
      remoteJid,
      {
        text:
          `_⚠️ Format Penggunaan:_\n\n` +
          `_💬 Contoh:_\n` +
          `_*${prefix}${command} 23:10*_\n` +
          `_*${prefix}${command} 23:10 Grup ditutup, lanjut besok ya*_\n` +
          `_*${prefix}${command} off*_\n\n` +
          `_Keterangan:_\n` +
          `_- Jika hanya isi jam, bot memakai teks default._\n` +
          `_- Jika isi jam + teks, bot akan mengirim teks custom saat grup ditutup otomatis._\n` +
          `_- Bot akan menutup grup otomatis pada jam tersebut setiap hari._\n\n` +
          `_Untuk menghapus jadwal close grup otomatis:_\n_*${prefix}${command} off*_`,
      },
      { quoted: message },
    );
    return;
  }

  // ── Hapus jadwal ────────────────────────────────────────────────────────
  if (isi.toLowerCase() === 'off') {
    await setGroupSchedule(sock, remoteJid, 'off', 'closeTime');
    await setJadwalTeks(remoteJid, 'closeText', ''); // teks custom ikut dibuang

    await sock.sendMessage(
      remoteJid,
      { text: '_✅ Close Grub otomatis berhasil di hapus_' },
      { quoted: message },
    );
    return;
  }

  // ── Jam + teks (teks opsional) ──────────────────────────────────────────
  const [jam, ...sisa] = isi.split(/\s+/);
  const teksCustom = sisa.join(' ').trim();

  if (!TIME_REGEX.test(jam)) {
    await sock.sendMessage(
      remoteJid,
      {
        text:
          `_⚠️ Format jam tidak valid!_\n\n_Pastikan format jam adalah HH:mm (contoh: 23:10)_\n\n` +
          `_💬 Contoh:_ _*${prefix}${command} 23:10 Grup ditutup*_`,
      },
      { quoted: message },
    );
    return;
  }

  await setGroupSchedule(sock, remoteJid, jam, 'closeTime');
  await setJadwalTeks(remoteJid, 'closeText', teksCustom);

  const serverTime = convertTime(jam);
  const { hours, minutes } = getTimeRemaining(serverTime);
  const teksDipakai = getJadwalTeks(remoteJid, 'closeText') || mess.action.grub_close;

  await sock.sendMessage(
    remoteJid,
    {
      text:
        `✅ _Berhasil, Grup otomatis ditutup pada jam *${jam}* WIB_\n` +
        `⏰ _Sekitar ${hours} jam ${minutes} menit lagi_\n\n` +
        `│ Pesan : _${teksDipakai}_${teksCustom ? '' : ' _(default)_'}\n\n` +
        analisisSyarat(sock, remoteJid, groupMetadata, jam),
    },
    { quoted: message },
  );
}

export default {
  handle,
  Commands: ['setclosegc'],
  OnlyPremium: false,
  OnlyOwner: false,
};
