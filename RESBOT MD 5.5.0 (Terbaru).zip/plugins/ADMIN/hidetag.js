import mess from '../../strings.js';
import { downloadQuotedMedia, downloadMedia } from '../../lib/utils.js';
import fs from 'fs/promises';
import { getGroupMetadata } from '../../lib/cache.js';
import { sendImageAsSticker } from '../../lib/exif.js';
import { isOwner } from '../../lib/users.js';
import config from '../../config.js';

function getMediaContent(media) {
  if (media.type === 'video' || media.type === 'image') {
    return media.content.caption;
  }
  return media.content || media.text;
}

async function handle(sock, messageInfo) {
  const { remoteJid, isGroup, message, sender, senderLid, content, isQuoted, type } = messageInfo;
  if (!isGroup) return; // Only Grub

  try {
    // Mendapatkan metadata grup (null kalau gagal diambil, mis. timeout)
    const groupMetadata = await getGroupMetadata(sock, remoteJid);
    if (!groupMetadata?.participants) {
      await sock.sendMessage(
        remoteJid,
        { text: '⚠️ Gagal mengambil data grup, coba lagi beberapa saat.' },
        { quoted: message },
      );
      return;
    }
    const participants = groupMetadata.participants;
    const isAdmin = participants.some(
      (p) => (p.phoneNumber === sender || p.id === senderLid) && p.admin,
    );

    const isOwnerUsers = isOwner(senderLid);

    if (!isAdmin && !isOwnerUsers) {
      await sock.sendMessage(remoteJid, { text: mess.general.isAdmin }, { quoted: message });
      return;
    }

    // Unduh media
    const media = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message);

    const mediaType = isQuoted ? `${isQuoted.type}Message` : `${type}Message`;
    let mediaContent = '';

    if (isQuoted) {
      mediaContent = getMediaContent(isQuoted);
    }

    if (content && content.trim() !== '') {
      mediaContent = content.trim();
    }

    // Kirim media atau pesan teks
    if (media) {
      const mediaPath = `tmp/${media}`;
      await checkFileExists(mediaPath); // Validasi file
      await sendMedia(sock, remoteJid, mediaType, mediaPath, mediaContent, message, participants);
    } else {
      await sendTextMessage(sock, remoteJid, mediaContent, message, participants);
    }
  } catch (error) {
    // `participants` hanya ada di dalam blok try, jadi pesan error dikirim
    // tanpa tag semua anggota (dulu memicu "participants is not defined").
    console.error('Error hidetag:', error.message);
    await sock
      .sendMessage(remoteJid, { text: '⚠️ Terjadi kesalahan: ' + error.message }, { quoted: message })
      .catch(() => {});
  }
}

// Fungsi untuk validasi keberadaan file
async function checkFileExists(path) {
  try {
    await fs.access(path);
  } catch {
    throw new Error(`File media tidak ditemukan: ${path}`);
  }
}

// Fungsi untuk mengirim pesan teks
async function sendTextMessage(sock, remoteJid, text, quoted, participants) {
  text = typeof text === 'string' ? text : '';
  await sock.sendMessage(
    remoteJid,
    { text: text, mentions: participants.map((p) => p.id) },
    { quoted },
  );
}

// Fungsi untuk mengirim media
async function sendMedia(sock, remoteJid, type, mediaPath, caption, message, participants) {
  const mediaOptions = {
    audioMessage: { audio: await fs.readFile(mediaPath) },
    imageMessage: {
      image: await fs.readFile(mediaPath),
      caption,
      mentions: participants.map((p) => p.id),
    },
    videoMessage: {
      video: await fs.readFile(mediaPath),
      caption,
      mentions: participants.map((p) => p.id),
    },
    documentMessage: {
      document: await fs.readFile(mediaPath),
      caption,
      mentions: participants.map((p) => p.id),
    },
    stickerMessage: {
      stickerMessage: await fs.readFile(mediaPath),
      caption,
      mentions: participants.map((p) => p.id),
    },
  };

  const options = mediaOptions[type];
  if (!options) {
    throw new Error(`Tipe media tidak didukung: ${type}`);
  }

  if (type == 'stickerMessage') {
    const options2 = {
      packname: config.sticker_packname,
      author: config.sticker_author,
      mentions: options.mentions,
    };
    const buffer = options.stickerMessage;
    // Kirim stiker
    await sendImageAsSticker(sock, remoteJid, buffer, options2, message);
    return;
  }
  await sock.sendMessage(remoteJid, options, { quoted: message });
}

export default {
  handle,
  Commands: ['hidetag', 'h', 'hidetak'],
  OnlyPremium: false,
  OnlyOwner: false,
};
