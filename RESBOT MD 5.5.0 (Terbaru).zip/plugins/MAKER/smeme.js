import ApiAutoresbotModule from 'api-autoresbot';
const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule;
import fs from 'fs';
import path from 'path';

import config from '../../config.js';
import { sendImageAsSticker } from '../../lib/exif.js';
import { downloadQuotedMedia, downloadMedia } from '../../lib/utils.js';
import { uploadImageFile, logShort } from '../../lib/uploader.js';

function detectMime(buffer) {
  if (!buffer || buffer.length < 12) return null;

  // PNG
  if (buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47) {
    return 'image/png';
  }

  // JPG
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return 'image/jpeg';
  }

  // GIF
  if (
    buffer.subarray(0, 6).toString() === 'GIF87a' ||
    buffer.subarray(0, 6).toString() === 'GIF89a'
  ) {
    return 'image/gif';
  }

  // WEBP
  if (buffer.subarray(0, 4).toString() === 'RIFF' && buffer.subarray(8, 12).toString() === 'WEBP') {
    return 'image/webp';
  }

  return null;
}

/** Pesan untuk balasan API yang bukan gambar (mis. JSON error). */
function alasanBukanGambar(buffer) {
  try {
    const data = JSON.parse(buffer.toString('utf8'));
    const pesan = data?.message || data?.error;
    if (pesan) return `API smeme menolak: ${pesan}`;
  } catch {
    // bukan JSON
  }
  return 'API smeme tidak mengembalikan gambar. Silakan coba lagi nanti.';
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, type, isQuoted, content, prefix, command } = messageInfo;

  try {
    if (!content) {
      return await sock.sendMessage(
        remoteJid,
        {
          text: `_⚠️ Format Penggunaan:_\n\n_💬 Contoh:_ *${prefix + command} atas|bawah*`,
        },
        { quoted: message },
      );
    }

    await sock.sendMessage(remoteJid, {
      react: {
        text: '⏰',
        key: message.key,
      },
    });

    const mediaType = isQuoted ? isQuoted.type : type;

    if (!['image', 'sticker'].includes(mediaType)) {
      return await sock.sendMessage(
        remoteJid,
        {
          text: `⚠️ Kirim atau balas gambar/sticker dengan caption *${prefix + command}*`,
        },
        { quoted: message },
      );
    }

    const [text1 = '', text2 = ''] = content.split('|');

    const media = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message);

    const mediaPath = path.join('tmp', media);
    if (!fs.existsSync(mediaPath)) {
      throw new Error('File media tidak ditemukan setelah diunduh.');
    }

    // convert: false — plugin ini menerima gambar MAUPUN sticker, dan sticker
    // (WebP) harus tetap dikirim apa adanya. Yang dibetulkan hanya nama file &
    // content-type agar cocok dengan isi sebenarnya; untuk sticker hasilnya
    // sama seperti sebelumnya, untuk gambar ber-isi WebP/PNG inilah perbaikannya.
    // shrink: true — gambar di atas 5 MB (foto HD) diperkecil dulu, kalau tidak
    // server upload menolak dengan "HTTP 413 - File too large".
    const imageUrl = await uploadImageFile(mediaPath, {
      convert: false,
      shrink: true,
      label: 'SMEME',
    });

    const api = new ApiAutoresbot(config.APIKEY);

    const buffer = await api.getBuffer('/api/maker/smeme', {
      text: text1,
      text2,
      pp: imageUrl,
      width: 500,
      height: 500,
    });

    if (!buffer || !Buffer.isBuffer(buffer) || buffer.length === 0) {
      throw new Error('API smeme tidak mengembalikan buffer yang valid.');
    }

    const mime = detectMime(buffer);

    // Bukan gambar -> biasanya JSON berisi alasan gagal. Dulu kasus ini (dan
    // gambar selain WebP/PNG) tidak dibalas sama sekali: pengguna hanya
    // melihat ⏰ padahal limit sudah terpotong.
    if (!mime) {
      throw new Error(alasanBukanGambar(buffer));
    }

    if (mime === 'image/webp') {
      // Kirimkan stiker sebagai respon
      await sock.sendMessage(
        remoteJid,
        {
          sticker: buffer,
        },
        { quoted: message },
      );
    } else {
      // PNG / JPEG / GIF -> diubah jadi sticker
      await sendImageAsSticker(
        sock,
        remoteJid,
        buffer,
        {
          packname: config.sticker_packname,
          author: config.sticker_author,
        },
        message,
      );
    }

    // await sock.sendMessage(remoteJid, {
    //   react: {
    //     text: '✅',
    //     key: message.key,
    //   },
    // });
  } catch (error) {
    // Satu baris ringkas di console; detail lengkap masuk logs/api.log.
    logShort('SMEME', `Error: ${error?.serverMessage || error?.message || error}`, error);

    await sock.sendMessage(
      remoteJid,
      {
        text: `❌ Gagal membuat sticker meme.\n\n${error.message}`,
      },
      { quoted: message },
    );

    try {
      await sock.sendMessage(remoteJid, {
        react: {
          text: '❌',
          key: message.key,
        },
      });
    } catch (err) {
      // Reaksi ❌ hanya kosmetik; kegagalannya tidak boleh menutupi error asli.
      console.warn('[SMEME] Gagal mengirim reaksi error:', err.message);
    }
  }
}

export default {
  handle,
  Commands: ['smeme'],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};
