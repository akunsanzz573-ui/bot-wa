import { addSewa, findSewa } from "../../lib/sewa.js";
import config from "../../config.js";
import { selisihHari, hariini } from "../../lib/utils.js";
import { gabungGrupViaLink, pastikanAnggota } from "../../lib/gabungGrup.js";

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, sender, prefix, command } = messageInfo;

  // Validasi input kosong atau tidak sesuai format
  if (!content || content.trim() === "") {
    return await sock.sendMessage(
      remoteJid,
      {
        text: `_⚠️ Format Penggunaan:_ \n\n_💬 Contoh:_ _*${
          prefix + command
        } https://chat.whatsapp.com/xxx 30*_\n\n_*30* artinya penambahan 30 hari dihitung dari sisa waktu sewabot_\n\n_Jika Bot Belum Bergabung ke Grub Sewa Silakan ketik *.sewabot*_`,
      },
      { quoted: message }
    );
  }

  // Split content menjadi array untuk memisahkan link dan jumlah hari
  const args = content.trim().split(" ");
  if (args.length < 2) {
    return await sock.sendMessage(
      remoteJid,
      {
        text: `⚠️ Format tidak valid. Contoh penggunaan:\n\n_*${
          prefix + command
        } https://chat.whatsapp.com/xxx 30*_`,
      },
      { quoted: message }
    );
  }

 
  const groupIdRaw = args[0];
  const linkGrub = groupIdRaw ? groupIdRaw.split("?")[0] : null;
  
  const totalHari = parseInt(args[1], 10); // Konversi hari menjadi angka

  // Validasi link grup
  if (!linkGrub.includes("chat.whatsapp.com")) {
    return await sock.sendMessage(
      remoteJid,
      {
        text: `⚠️ Link grup harus mengandung 'chat.whatsapp.com'. Contoh penggunaan:\n\n_*${
          prefix + command
        } https://chat.whatsapp.com/xxx 30*_`,
      },
      { quoted: message }
    );
  }

  // Validasi jumlah hari
  if (isNaN(totalHari) || totalHari <= 0) {
    return await sock.sendMessage(
      remoteJid,
      {
        text: `⚠️ Jumlah hari tidak valid. Contoh penggunaan:\n\n_*${
          prefix + command
        } https://chat.whatsapp.com/xxx 30*_`,
      },
      { quoted: message }
    );
  }

  // Ekstraksi kode grup dari link

  const result_sewa = linkGrub
  .replace("https://chat.whatsapp.com/", "")
  .trim();

  let res_linkgc = "";

  const currentDate = new Date();
  const expirationDate = new Date(
    currentDate.getTime() + totalHari * 24 * 60 * 60 * 1000 + 1 * 60 * 60 * 1000
  );
  const timestampExpiration = expirationDate.getTime();

  try {
    // Dulu node IQ mentah dikirim lalu dibaca lewat res.content[0].attrs.
    // Bentuk node hasil decode zapo berbeda, sehingga id & subject terbaca
    // undefined dan sewa tersimpan sebagai "undefined@g.us". Sekarang dipakai
    // parser resmi zapo yang mengembalikan objek bertipe.
    const infoGrub = await sock.groupGetInviteInfo(result_sewa);

    if (!infoGrub?.jid) {
      throw new Error("Link grup tidak valid atau info grup tidak terbaca");
    }

    res_linkgc = infoGrub.jid;
    const res_namegc = infoGrub.subject;

    // cek apakah data ada
    const cekSewa = await findSewa(res_linkgc);
    if (!cekSewa) {
      return await sock.sendMessage(
        remoteJid,
        {
          text: `⚠️ _*Nomor Bot Belum Pernah Bergabung*_\n\n_Silakan Ketik *.sewabot* untuk membuat Sewa Baru_`,
        },
        { quoted: message }
      );
    }

    // Bot bisa saja sudah keluar/dikeluarkan dari grup ini. Dulu kegagalan
    // bergabung ditelan, jadi perpanjangan tetap tercatat walau botnya tidak
    // ada di grup. Sekarang dipastikan dulu; join hanya kalau bot belum di
    // dalam grup (join ulang bisa gagal walau bot sudah anggota).
    let hasilGabung = { ok: true };
    let cek = await pastikanAnggota(sock, res_linkgc);
    if (!cek.ok) {
      hasilGabung = await gabungGrupViaLink(sock, result_sewa);
      cek = await pastikanAnggota(sock, res_linkgc);
    }

    if (!cek.ok) {
      return await sock.sendMessage(
        remoteJid,
        {
          text:
            `⚠️ _Gagal memperpanjang sewa._\n\n` +
            `${hasilGabung.ok ? cek.alasan : hasilGabung.alasan}\n\n` +
            `_Perpanjangan TIDAK dicatat._`,
        },
        { quoted: message },
      );
    }

    const totalSewa =
      cekSewa.expired + totalHari * 24 * 60 * 60 * 1000 + 1 * 60 * 60 * 1000;

    await addSewa(res_linkgc, {
      linkGrub: linkGrub,
      expired: totalSewa,
    });

    // Kirim pesan berhasil
    return await sock.sendMessage(
      remoteJid,
      {
        text:
          `_*Perpanjangan Berhasil*_` +
          `\n\nName Grub : *${res_namegc}*` +
          `\nNomor Bot : ${config.phone_number_bot}` +
          `\nExpired : *${selisihHari(totalSewa)}*` +
          `\n\n_Untuk Mengecek status sewa ketik *.ceksewa* pada grub tersebut_`,
      },
      { quoted: message }
    );
  } catch (error) {
    console.error("Gagal bergabung ke grup:", error);

    // Pesan error default
    let info = "_Pastikan link grup valid._";

    // Periksa pesan error
    if (error instanceof Error && error.message.includes("not-authorized")) {
      info = `_Kemungkinan Anda pernah dikeluarkan dari grup. Solusi: undang bot kembali atau masukkan secara manual._`;
    }

    // Kirim pesan error ke pengguna
    return await sock.sendMessage(
      remoteJid,
      {
        text: `⚠️ _Gagal bergabung ke grup._\n\n${info}`,
      },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["tambahsewa"],
  OnlyPremium: false,
  OnlyOwner: true,
};
