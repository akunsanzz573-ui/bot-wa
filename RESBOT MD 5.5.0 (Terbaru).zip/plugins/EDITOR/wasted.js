import ApiAutoresbotModule from "api-autoresbot";
const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule;

import fs from "fs";
import path from "path";
import mess from "../../strings.js";
import config from "../../config.js";

import { downloadQuotedMedia, downloadMedia, reply } from "../../lib/utils.js";
import { uploadImageFile, logShort } from "../../lib/uploader.js";

async function handle(sock, messageInfo) {
  const { m, remoteJid, message, content, prefix, command, type, isQuoted } =
    messageInfo;

  try {
    const mediaType = isQuoted ? isQuoted.type : type;
    if (mediaType !== "image") {
      return await reply(
        m,
        `⚠️ _Kirim/Balas gambar dengan caption *${prefix + command}*_`
      );
    }

    // Tampilkan reaksi "Loading"
    await sock.sendMessage(remoteJid, {
      react: { text: "⏰", key: message.key },
    });

    // Download & Upload media
    const media = isQuoted
      ? await downloadQuotedMedia(message)
      : await downloadMedia(message);
    const mediaPath = path.join("tmp", media);

    if (!fs.existsSync(mediaPath)) {
      throw new Error("File media tidak ditemukan setelah diunduh.");
    }

    // Format dinormalisasi lebih dulu: WhatsApp menyimpan setiap imageMessage
    // sebagai .jpg walau isinya WebP/PNG, dan server uploader menolak bila isi
    // file tidak cocok dengan format yang dideklarasikan.
    const url = await uploadImageFile(mediaPath, { convert: true, label: "WASTED" });

    const api = new ApiAutoresbot(config.APIKEY);
    const MediaBuffer = await api.getBuffer("/api/maker/wasted", { url });

    if (!Buffer.isBuffer(MediaBuffer)) {
      throw new Error("Invalid response: Expected Buffer.");
    }

    await sock.sendMessage(
      remoteJid,
      {
        image: MediaBuffer,
        caption: mess.general.success,
      },
      { quoted: message }
    );
  } catch (error) {
    // Satu baris ringkas di console; detail lengkap masuk logs/api.log.
    // (Label sebelumnya tertulis "Hd" — salin-tempel dari plugin lain.)
    logShort("WASTED", `Error: ${error?.serverMessage || error?.message || error}`, error);

    // Kirim pesan kesalahan yang lebih informatif
    const errorMessage = `_Terjadi kesalahan saat memproses gambar._`;
    await reply(m, errorMessage);
  }
}

export default {
  handle,
  Commands: ["wasted"], // Perintah yang diproses oleh handler ini
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1, // Jumlah limit yang akan dikurangi
};
