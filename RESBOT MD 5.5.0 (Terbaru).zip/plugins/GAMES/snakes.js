const DATABASE = {}; // Simpan game di RAM

const MONEY_MENANG = 100;
const opsiLoading = 'sticker'; // sticker, emoticon

import fs from 'fs';
import path from 'path';

import { getProfilePictureUrl } from '../../lib/cache.js';
// Pemain disimpan sebagai JID lengkap (senderLid), jadi mention memakai
// daftar JID eksplisit -> akurat untuk JID maupun LID.
import { getBuffer, sendTextWithMentions, sendImageWithMentions } from '../../lib/utils.js';
import { addUser, updateUser, deleteUser, findUser } from '../../lib/users.js';
import axios from 'axios';
import retryRequest from '../../lib/retry.js';

/**
 * Ambil gambar papan dari API, dengan percobaan ulang.
 *
 * Dulu memakai getBuffer() yang mengembalikan `false` saat gagal (tanpa
 * alasan), lalu `false` itu diteruskan ke pengiriman gambar dan berakhir
 * dengan pesan "Gagal mengambil gambar papan dari api." tanpa penjelasan.
 * Sekarang: dicoba 3x (jeda 1-2 detik), isinya dipastikan benar-benar
 * gambar, dan alasannya dikembalikan apa adanya.
 */
async function ambilPapan(apiUrl) {
  return retryRequest(
    async () => {
      const res = await axios.get(apiUrl, {
        responseType: 'arraybuffer',
        timeout: 30000,
        validateStatus: () => true,
      });

      const buffer = Buffer.from(res.data || []);

      // API membalas galat sebagai JSON (kadang tetap dengan status 200).
      if (buffer[0] === 0x7b) {
        let pesan = 'API menolak permintaan';
        try {
          pesan = JSON.parse(buffer.toString('utf8'))?.message || pesan;
        } catch {
          /* biarkan pesan bawaan */
        }
        throw new Error(pesan);
      }

      if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
      if (buffer.length === 0) throw new Error('Balasan API kosong');

      return buffer;
    },
    { maxRetry: 3, label: 'SNAKES_PAPAN', logFile: 'api.log' },
  );
}

const snakes = {
  99: 41,
  95: 76,
  89: 53,
  66: 45,
  54: 31,
  43: 17,
  40: 2,
  27: 5,
};

const ladders = {
  4: 23,
  13: 46,
  33: 52,
  42: 63,
  50: 69,
  62: 81,
  74: 93,
};

let pendingDelete = null;

// Fungsi kirim sticker
async function kirimSticker(sock, remoteJid, namaFile, message) {
  try {
    const mediaPath = path.join(process.cwd(), 'database/assets', namaFile);

    // Cek apakah file ada
    if (!fs.existsSync(mediaPath)) {
      throw new Error(`File tidak ditemukan: ${mediaPath}`);
    }

    const buffer = fs.readFileSync(mediaPath);

    await sock.sendMessage(
      remoteJid,
      {
        sticker: buffer,
      },
      { quoted: message },
    );
  } catch (error) {
    console.error('Gagal mengirim stiker:', error.message);
  }
}

async function handle(sock, messageInfo) {
  const { remoteJid, senderLid, isGroup, message, content } = messageInfo;
  if (!isGroup) return;

  let game = DATABASE[remoteJid];
  if (!game) {
    game = {
      players: [],
      started: false,
      turnIndex: 0,
      positions: {},
    };
    DATABASE[remoteJid] = game;
  }

  const command = content?.toLowerCase();

  if (!content) {
    let infoText = '🎮 *Info Game Ular Tangga*\n';

    if (game.players.length === 0) {
      infoText += '👥 Belum ada pemain yang bergabung.\n';
    } else {
      const playerList = game.players
        .map(
          (p, i) =>
            `${i + 1}. @${p.split('@')[0]}${
              i === game.turnIndex && game.started ? ' 🔄 (giliran)' : ''
            }`,
        )
        .join('\n');
      infoText += `👥 Pemain (${game.players.length}/10):\n${playerList}\n`;
    }

    infoText += `\nStatus: ${game.started ? '🟢 Dimulai' : '🔴 Belum dimulai'}`;
    infoText += `\n\n✅ Gunakan *.snakes join* untuk bergabung\n🚀 Gunakan *.snakes start* untuk memulai game\ndan *.snakes reset* untuk mereset permainan`;

    return await sendTextWithMentions(sock, remoteJid, infoText, game.players, message);
  }

  // Join game
  if (command === 'join') {
    if (game.started) {
      return await sock.sendMessage(
        remoteJid,
        { text: '⛔ Game sudah dimulai, tidak bisa bergabung lagi.' },
        { quoted: message },
      );
    }
    if (game.players.includes(senderLid)) {
      return await sock.sendMessage(
        remoteJid,
        { text: '⚠️ Kamu sudah bergabung.' },
        { quoted: message },
      );
    }
    if (game.players.length >= 10) {
      return await sock.sendMessage(
        remoteJid,
        { text: '🚫 Maksimal 10 pemain sudah tercapai.' },
        { quoted: message },
      );
    }

    game.players.push(senderLid);
    game.positions[senderLid] = 1;
    return await sendTextWithMentions(
      sock,
      remoteJid,
      `✅ @${senderLid.split('@')[0]} berhasil bergabung. Total pemain: ${game.players.length}`,
      [senderLid],
      message,
    );
  }

  // Start game
  if (command === 'start') {
    if (game.started) {
      return await sock.sendMessage(
        remoteJid,
        { text: '🟡 Game sudah dimulai.' },
        { quoted: message },
      );
    }
    if (game.players.length < 2) {
      return await sock.sendMessage(
        remoteJid,
        { text: '❌ Minimal 2 pemain untuk memulai permainan.' },
        { quoted: message },
      );
    }
    game.started = true;
    game.turnIndex = 0;
    return await sendTextWithMentions(
      sock,
      remoteJid,
      `🎲 Permainan dimulai!\nGiliran pertama: @${
        game.players[0].split('@')[0]
      } ketik ".snakes play" untuk lempar dadu.`,
      [game.players[0]],
      message,
    );
  }

  // Play (lempar dadu)
  if (command === 'play') {
    if (!game.started) {
      return await sock.sendMessage(
        remoteJid,
        { text: '❌ Game belum dimulai. Ketik .snakes join dan .snakes start' },
        { quoted: message },
      );
    }

    if (game.players[game.turnIndex] !== senderLid) {
      return await sendTextWithMentions(
        sock,
        remoteJid,
        `🔄 Bukan giliranmu. Sekarang giliran: @${game.players[game.turnIndex].split('@')[0]}`,
        [game.players[game.turnIndex]],
        message,
      );
    }

    const dice = Math.floor(Math.random() * 6) + 1;
    let posBefore = game.positions[senderLid];
    game.positions[senderLid] += dice;

    // Cek posisi tidak boleh lebih dari 100
    if (game.positions[senderLid] > 100) {
      const overflow = game.positions[senderLid] - 100;
      game.positions[senderLid] = 100 - overflow;
    }

    let moveInfo = '';
    if (snakes[game.positions[senderLid]]) {
      game.positions[senderLid] = snakes[game.positions[senderLid]];
      moveInfo = '🐍 Kena ular! Turun';
    } else if (ladders[game.positions[senderLid]]) {
      game.positions[senderLid] = ladders[game.positions[senderLid]];
      moveInfo = '🪜 Naik tangga!';
    }

    // Cek menang
    if (game.positions[senderLid] === 100) {
      delete DATABASE[remoteJid];

      // Tambahkan money user menang

      const user = await findUser(senderLid, 'snakes game');

      if (user) {
        const [docId, userData] = user;
        const moneyAdd = (userData.money || 0) + MONEY_MENANG; // Default money ke 0 jika undefined
        await updateUser(senderLid, { money: moneyAdd });
      } else {
      }

      return await sendTextWithMentions(
        sock,
        remoteJid,
        `🏆 @${senderLid.split('@')[0]} menang! 🎉🎉\n\nAnda Dapat ${MONEY_MENANG} Money `,
        [senderLid],
        message,
      );
    }

    // Giliran berikutnya
    game.turnIndex = (game.turnIndex + 1) % game.players.length;

    // Update game ke DATABASE (tidak wajib karena objek sudah referensi)
    DATABASE[remoteJid] = game;

    // Ambil semua avatar pemain untuk gambar.
    // Dulu foto profil diambil SATU per SATU (await di dalam loop) tiap giliran,
    // jadi makin banyak pemain makin lama jedanya. Sekarang:
    //  - diambil paralel (Promise.all), dan
    //  - di-cache per permainan supaya tidak di-fetch ulang tiap lemparan.
    if (!game.ppCache) game.ppCache = {};

    const ppList = await Promise.all(
      game.players.map(async (player) => {
        if (game.ppCache[player]) return game.ppCache[player];
        const pp = await getProfilePictureUrl(sock, player);
        game.ppCache[player] = pp;
        return pp;
      }),
    );

    const params = new URLSearchParams();
    game.players.forEach((player, i) => {
      params.append('pp', ppList[i]);
      params.append('positions', game.positions[player] || 1);
    });

    const API_URL = `https://api.autoresbot.com/api/maker/ulartangga?${params.toString()}`;

    try {
      if (opsiLoading == 'emoticon') {
        await sock.sendMessage(remoteJid, {
          react: { text: '🎲', key: message.key },
        });
      } else if (opsiLoading == 'sticker') {
        await kirimSticker(sock, remoteJid, `${dice}.webp`, message);
      }

      const buffer = await ambilPapan(API_URL);

      const customizedMessage = `🎲 @${
        senderLid.split('@')[0]
      } melempar dadu: ${dice}\n📍 Posisi sekarang: ${
        game.positions[senderLid]
      } ${moveInfo}\n➡️ Giliran selanjutnya: @${game.players[game.turnIndex].split('@')[0]}`;

      const result = await sendImageWithMentions(
        sock,
        remoteJid,
        buffer,
        customizedMessage,
        [senderLid, game.players[game.turnIndex]],
        message,
      );

      if (result) {
        if (pendingDelete) {
          await sock.sendMessage(remoteJid, {
            delete: {
              remoteJid: remoteJid,
              fromMe: true,
              id: pendingDelete,
              participant: undefined, // tidak perlu disertakan
            },
          });
        }

        pendingDelete = result?.key?.id;
      }
    } catch (err) {
      console.error('[SNAKES] Gagal mengambil papan:', err?.message || err);

      // Gambar papan gagal SETELAH 3x percobaan -> permainan tidak
      // dihentikan: hasil lemparan tetap diumumkan sebagai teks, supaya
      // giliran berikutnya bisa jalan terus.
      const teksCadangan =
        `🎲 @${senderLid.split('@')[0]} melempar dadu: ${dice}
` +
        `📍 Posisi sekarang: ${game.positions[senderLid]} ${moveInfo}
` +
        `➡️ Giliran selanjutnya: @${game.players[game.turnIndex].split('@')[0]}

` +
        `⚠️ _Gambar papan gagal dimuat: ${err?.message || 'tidak diketahui'}_`;

      await sendTextWithMentions(
        sock,
        remoteJid,
        teksCadangan,
        [senderLid, game.players[game.turnIndex]],
        message,
      );
    }
  }

  // Reset game
  if (command === 'reset') {
    if (game.players.length === 0 && !game.started) {
      return await sock.sendMessage(
        remoteJid,
        {
          text: '⚠️ Tidak ada permainan yang sedang berlangsung untuk direset.',
        },
        { quoted: message },
      );
    }

    delete DATABASE[remoteJid];
    return await sock.sendMessage(
      remoteJid,
      {
        text: '✅ Permainan direset. Gunakan *.snakes join* untuk memulai lagi.',
      },
      { quoted: message },
    );
  }
}

export default {
  handle,
  Commands: ['snakes'],
  OnlyPremium: false,
  OnlyOwner: false,
};
