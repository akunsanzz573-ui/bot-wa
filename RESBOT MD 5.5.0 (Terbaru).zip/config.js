/*
⚠️ PERINGATAN:
Script ini **TIDAK BOLEH DIPERJUALBELIKAN** dalam bentuk apa pun!

╔══════════════════════════════════════════════╗
║                🛠️ INFORMASI SCRIPT           ║
╠══════════════════════════════════════════════╣
║ 📦 Version   : 5.5.0
║ 👨‍💻 Developer  : Azhari Creative              ║
║ 🌐 Website    : https://autoresbot.com       ║
║ 💻 GitHub  : github.com/autoresbot/resbot-md ║
╚══════════════════════════════════════════════╝

📌 Mulai 11 April 2025,
Script **Autoresbot** resmi menjadi **Open Source** dan dapat digunakan secara gratis:
🔗 https://autoresbot.com
*/

import fs from 'fs';
import moment from 'moment-timezone';

const CONNECTION = 'pairing'; // qr atau pairing
// Kode pairing custom (opsional — kosongkan agar dibuat otomatis).
// Aturan dari WhatsApp:
//   • TEPAT 8 karakter (tanda '-' boleh, tidak ikut dihitung)
//   • Huruf kecil otomatis dijadikan huruf besar
//   • Karakter yang boleh: 123456789ABCDEFGHJKLMNPQRSTVWXYZ
//   • 0, I, O, dan U TIDAK boleh — mudah tertukar saat dibaca (O/0, I/1, U/V)
// Contoh valid  : 'RESBTMD1', 'WABTMD12', 'RESBTMD9'
// Contoh DITOLAK: 'RESBOTMD' (ada O), 'AZHARI12' (ada I), 'RESB0TMD' (ada 0)
const PAIRING_CODE = '';
const OWNER_NAME = 'Autoresbot';
const NOMOR_BOT = ''; // 628xx nomor wa
const DESTINATION = 'group'; // group , private, both
const APIKEY = ''; // apikey dari autoresbot.com (paket apikey)
const RATE_LIMIT = 3000; // 3 detik/chat
const SIMILARITY = true; // Pencarian kemiripan command (true, false)
// Jejak chat di console: tiap pesan dicetak MASUK -> LANJUT -> SELESAI/BERHENTI,
// supaya ketahuan pesannya benar-benar sampai atau berhenti di fitur mana.
//   null  = ikut MODE di bawah (nyala di development, MATI di production)
//   true  = dipaksa nyala, termasuk di production (untuk melacak masalah)
//   false = dipaksa mati
const TRACE_CHAT = null;
const MODE = 'production'; // [production, development] (jangan di ubah kecuali anda developer)
const VERSION = global.version; // don't edit

const EMAIL = 'autoresbot@gmail.com';
const REGION = 'Indonesia';
const WEBSITE = 'autoresbot.com';
const DATA_OWNER = []; // cara ambil owner https://youtu.be/qrRXPCSFvRo?si=KOWdFhrScHN7Ugd4

// Nama yang ditampilkan di command .owner.
// Key  : nomor/LID owner (boleh ditulis polos, dengan @lid, atau @s.whatsapp.net)
// Value: nama yang ingin ditampilkan
// Owner yang tidak didaftarkan di sini akan memakai OWNER_NAME (kalau ownernya
// cuma satu) atau nomornya sendiri.
const OWNER_NAMES = {
  '69243815079978@lid': 'Azhari',
  '231911473578043': 'Autoresbot',
};

// Konfiqurasi Chat
const ANTI_CALL = false; // jika true (setiap yang nelpon pribadi akan di block)
const AUTO_READ = false; // jika true (setiap chat akan di baca/centang 2 biru)
const AUTO_BACKUP = false; // jika true (setiap restart server & tiap 4 jam, data backup dikirim ke Telegram - isi TELEGRAM di bawah);

// Konfiqurasi Backup Telegram (dipakai .backuptele & AUTO_BACKUP)
// Token   : dari @BotFather -> /newbot -> salin token (format 123456789:AAE-xxxx)
// Chat ID : buka Telegram, cari @Get_myidrobot, klik Start - ID kamu tampil di sana
//           (untuk grup: ketik .backuptele id di WhatsApp; id grup diawali tanda minus)
// Biarkan kosong jika tidak dipakai.
const TELEGRAM_BOT_TOKEN = '';
const TELEGRAM_CHAT_ID = '';
// Tidak dipakai lagi: AUTO_BACKUP sekarang selalu (dan hanya) dikirim ke Telegram.
const AUTO_BACKUP_TELEGRAM = false;
const MIDNIGHT_RESTART = false; // Restart setiap jam 12 malam
const PRESENCE_UPDATE = ''; // unavailable, available, composing, recording, paused
const ALWAYS_ONLINE = true; // jika true (bot selalu tampil "aktif" di Perangkat Tertaut)
const TYPE_WELCOME = '1'; // 1, 2, 3, 4, 5, 6 text dan random
const BG_WELCOME2 = 'https://api.autoresbot.com/api/maker/bg-default';

// Konfiqurasi Panel
// Tutor : https://youtu.be/ZAWb7tnKjoM?si=jMUiB13KkXE1H7IG
const PANEL_URL = '';
const PANEL_PLTA = '';
const PANEL_DESCRIPTION = 'Butuh Bantuan Hubungi 628xxxxx';
const PANEL_ID_EGG = 15;
const PANEL_ID_LOCATION = 1;
const PANEL_DEFAULT_DISK = 5120; // 5GB atau 0 (unlimited)
const PANEL_DEFAULT_CPU = 90;

// antibadword di grub
const BADWORD_WARNING = 3; // Jumlah maksimum peringatan sebelum tindakan diambil
const BADWORD_ACTION = 'both'; // tindakan setelah warning terpenuhi (kick, block, both)

// antispam di grub
const SPAM_LIMIT = 3; // Batas pesan dianggap spam
const SPAM_COULDOWN = 10; // Waktu cooldown dalam detik (10 detik)
const SPAM_WARNING = 3; // Jumlah maksimum peringatan sebelum tindakan diambil
const SPAM_ACTION = 'both'; // tindakan setelah warning terpenuhi (kick, block, both)

// More
const STATUS_SCHEDULED = true;

// Dashboard web (kelola database, config.js, dan file lewat browser)
// Di panel pterodactyl otomatis memakai port server (allocation). Jika server
// tidak punya port, dashboard tidak dijalankan & bot tetap jalan normal.
const DASHBOARD = false; // false = matikan dashboard
const DASHBOARD_PASSWORD = ''; // kosong = dibuat otomatis (lihat console / database/dashboard.json)
const DASHBOARD_PORT = 3000; // hanya dipakai saat dijalankan di PC (bukan panel)

const config = {
  APIKEY,
  phone_number_bot: NOMOR_BOT,
  type_connection: CONNECTION,
  pairing_code: PAIRING_CODE,
  bot_destination: DESTINATION,
  owner_name: OWNER_NAME,
  owner_number: DATA_OWNER,
  owner_names: OWNER_NAMES,
  owner_website: WEBSITE,
  owner_email: EMAIL,
  region: REGION,
  version: VERSION,
  rate_limit: RATE_LIMIT,
  status_prefix: true, // wajib prefix : atau false tanpa prefix
  prefix: ['.', '!', '#'],
  sticker_packname: OWNER_NAME,
  sticker_author: `Date: ${moment
    .tz('Asia/Jakarta')
    .format('DD/MM/YY')}\nYouTube: Azhari Creative\nOwner: 0852-4615-4386`,
  mode: MODE,
  commandSimilarity: SIMILARITY,
  trace_chat: TRACE_CHAT,
  anticall: ANTI_CALL,
  autoread: AUTO_READ,
  autobackup: AUTO_BACKUP,
  autobackup_telegram: AUTO_BACKUP_TELEGRAM,
  TELEGRAM: {
    token: TELEGRAM_BOT_TOKEN,
    chat_id: TELEGRAM_CHAT_ID,
  },
  PresenceUpdate: PRESENCE_UPDATE,
  always_online: ALWAYS_ONLINE,
  typewelcome: TYPE_WELCOME,
  bgwelcome2: BG_WELCOME2,
  midnight_restart: MIDNIGHT_RESTART,
  scheduled: STATUS_SCHEDULED,
  PANEL: {
    URL: PANEL_URL,
    KEY_APPLICATION: PANEL_PLTA,
    description: PANEL_DESCRIPTION,
    SERVER_EGG: PANEL_ID_EGG,
    id_location: PANEL_ID_LOCATION,
    default_disk: PANEL_DEFAULT_DISK,
    cpu_default: PANEL_DEFAULT_CPU,
  },
  SPAM: {
    limit: SPAM_LIMIT,
    couldown: SPAM_COULDOWN,
    warning: SPAM_WARNING,
    action: SPAM_ACTION,
  },
  BADWORD: {
    warning: BADWORD_WARNING,
    action: BADWORD_ACTION,
  },
  dashboard: {
    enabled: DASHBOARD,
    password: DASHBOARD_PASSWORD,
    port: DASHBOARD_PORT,
  },
};

// Override lokal (opsional): local.config.js tidak ikut ke git, dipakai untuk
// pengaturan di komputer sendiri tanpa mengubah file ini. Isinya object dengan
// key yang sama seperti `config` di atas; hanya key yang ditulis yang diganti.
// Contoh: lihat local.config.example.js
const LOCAL_CONFIG = new URL('./local.config.js', import.meta.url);
if (fs.existsSync(LOCAL_CONFIG)) {
  try {
    const local = (await import(LOCAL_CONFIG.href)).default;
    mergeConfig(config, local);
    console.log('[CONFIG] local.config.js dipakai');
  } catch (err) {
    console.warn(`[CONFIG] local.config.js gagal dimuat, memakai config.js saja: ${err.message}`);
  }
}

function mergeConfig(target, source) {
  if (!isPlainObject(source)) return;
  for (const [key, value] of Object.entries(source)) {
    if (isPlainObject(value) && isPlainObject(target[key])) mergeConfig(target[key], value);
    else target[key] = value;
  }
}

function isPlainObject(value) {
  return Object.prototype.toString.call(value) === '[object Object]';
}

export default config;
